import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Cropper from 'react-easy-crop';
import { ProcessingState } from '../types';
import {
  shareFileViaAndroidBridge,
  downloadFileWithAd,
  triggerBrowserDownload,
  showBannerAd,
  hideBannerAd,
  isAndroidBridgeAvailable,
  openSavedFileSafely,
  shareSavedFileSafely,
} from '../utils/shareHelper';
import BannerAdBar from '../components/BannerAdBar';
import DownloadSuccessAdArea from '../components/DownloadSuccessAdArea';
import QuickCompressModal from '../components/QuickCompressModal';
import { scanImageWithGoogleAI } from '../utils/geminiScanner';
import {
  isAndroidScannerAvailable,
  launchNativeScannerIfAvailable,
} from '../utils/scannerBridge';
import {
  CompressionPreset,
  ExportFileFormat,
  PageExportMode,
  SavedLocationFeedback,
  formatBytes,
  calculateLiveEstimates,
  buildExportBundle,
} from '../utils/exportCompressionHelper';

// Access external libraries from the window object
declare const jspdf: any;
declare const jscanify: any;
declare const JSZip: any;


type ScanFilter = 'none' | 'document' | 'magic_color' | 'bw' | 'grayscale';

interface CapturedPage {
  rawOriginal: string; // Unedited source for full reset
  original: string;    // Current base image (updated after crop/rotate)
  processed: string;   // Filtered output image
  filter: ScanFilter;
  id: string;
  name: string;
  date: string;
  width: number;
  height: number;
}

const A4_WIDTH_MM = 210;
const A4_HEIGHT_MM = 297;

const generateId = () => {
  if (typeof crypto !== 'undefined' && (crypto as any).randomUUID) {
    return (crypto as any).randomUUID();
  }
  return `${Math.random().toString(36).substring(2, 11)}-${Date.now().toString(36)}`;
};

// Fit an image into an A4 page while preserving its aspect ratio (centered)
const addImageFitted = (doc: any, page: CapturedPage) => {
  const imgW = page.width || A4_WIDTH_MM;
  const imgH = page.height || A4_HEIGHT_MM;
  const scale = Math.min(A4_WIDTH_MM / imgW, A4_HEIGHT_MM / imgH);
  const w = imgW * scale;
  const h = imgH * scale;
  const x = (A4_WIDTH_MM - w) / 2;
  const y = (A4_HEIGHT_MM - h) / 2;
  doc.addImage(page.processed, 'JPEG', x, y, w, h);
};

// Draw source image onto a fresh canvas sized to that image
const drawImageToFreshCanvas = (img: HTMLImageElement): HTMLCanvasElement => {
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0);
  }
  return canvas;
};

// Apply pixel filter to a canvas context
const applyPixelFilterToCanvas = (
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  filter: ScanFilter
) => {
  if (filter === 'none') return;

  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    if (filter === 'grayscale') {
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      data[i] = lum;
      data[i + 1] = lum;
      data[i + 2] = lum;
    } else if (filter === 'bw') {
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      const val = lum > 128 ? 255 : 0;
      data[i] = val;
      data[i + 1] = val;
      data[i + 2] = val;
    } else if (filter === 'magic_color') {
      data[i] = Math.min(255, Math.max(0, (r - 128) * 1.25 + 128 + 12));
      data[i + 1] = Math.min(255, Math.max(0, (g - 128) * 1.25 + 128 + 12));
      data[i + 2] = Math.min(255, Math.max(0, (b - 128) * 1.25 + 128 + 12));
    } else if (filter === 'document') {
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      const val = lum > 155 ? 255 : Math.max(0, lum * 0.5);
      data[i] = val;
      data[i + 1] = val;
      data[i + 2] = val;
    }
  }

  ctx.putImageData(imageData, 0, 0);
};

/**
 * Safely loads an image with crossOrigin only on remote HTTP URLs,
 * handles immediate in-memory cache completion, and enforces a safety timeout
 * so that WebViews and Safari never hang indefinitely on data: or blob: URIs.
 */
const loadImageSafely = (
  src: string,
  timeoutMs: number = 6000
): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    if (!src) {
      return reject(new Error('Empty image source'));
    }

    const img = new Image();
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error('Image load timed out'));
      }
    }, timeoutMs);

    // CRITICAL: NEVER set crossOrigin on data: or blob: URLs (causes silent hang in WebViews)
    if (src.startsWith('http://') || src.startsWith('https://')) {
      img.crossOrigin = 'anonymous';
    }

    const onComplete = () => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(img);
      }
    };

    img.onload = onComplete;
    img.onerror = (e) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        reject(e instanceof Error ? e : new Error('Image failed to load'));
      }
    };

    img.src = src;

    // In-memory synchronously decoded image check
    if (img.complete && img.naturalWidth > 0) {
      onComplete();
    }
  });
};

const Scan: React.FC = () => {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const allFileInputRef = useRef<HTMLInputElement>(null);
  const longPressTimerRef = useRef<any>(null);
  const scannerRef = useRef<any>(null);
  const pageCounterRef = useRef(0);
  const dragItemIndex = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPages, setCapturedPages] = useState<CapturedPage[]>([]);
  const [uiStep, setUiStep] = useState<'camera' | 'gallery' | 'preview'>('gallery');

  const [previewPage, setPreviewPage] = useState<CapturedPage | null>(null);
  const [isFlashOn, setIsFlashOn] = useState(false);
  const [isAutoMode, setIsAutoMode] = useState(true);
  const [activeTrack, setActiveTrack] = useState<MediaStreamTrack | null>(null);
  const [shutterFlash, setShutterFlash] = useState(false);
  const [captureNotice, setCaptureNotice] = useState<string | null>(null);

  // Snackbar Toast State with Action
  const [snackbar, setSnackbar] = useState<{
    visible: boolean;
    message: string;
    actionLabel?: string;
    onAction?: () => void;
    timerId?: any;
  }>({
    visible: false,
    message: '',
  });

  const showSnackbar = useCallback((message: string, actionLabel?: string, onAction?: () => void) => {
    setSnackbar((prev) => {
      if (prev.timerId) clearTimeout(prev.timerId);
      const timerId = setTimeout(() => {
        setSnackbar((s) => ({ ...s, visible: false }));
      }, 5500);
      return {
        visible: true,
        message,
        actionLabel,
        onAction,
        timerId,
      };
    });
  }, []);

  // Cropping State
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<any>(null);
  const [isCropping, setIsCropping] = useState(false);

  // Project & Export State
  const [folderName, setFolderName] = useState('Scan_Project_01');
  const [isRenamingFolder, setIsRenamingFolder] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [exportFormat, setExportFormat] = useState<'PDF' | 'JPG'>('PDF');

  // Menus & Modals
  const [showTopMenu, setShowTopMenu] = useState(false);
  const [selectedMenuPage, setSelectedMenuPage] = useState<CapturedPage | null>(null);
  const [editingPageId, setEditingPageId] = useState<string | null>(null);
  const [editingPageName, setEditingPageName] = useState<string>('');
  const [renameModalPage, setRenameModalPage] = useState<CapturedPage | null>(null);
  const [renameInputVal, setRenameInputVal] = useState<string>('');

  // Share Modal Toggles
  const [enablePassword, setEnablePassword] = useState(false);
  const [pdfPassword, setPdfPassword] = useState('');
  const [enableOCR, setEnableOCR] = useState(false);
  const [saveSeparately, setSaveSeparately] = useState(false);

  // Multi-select State
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Processing & Result State
  const [state, setState] = useState<ProcessingState>({ status: 'idle', progress: 0 });
  const [hasDownloaded, setHasDownloaded] = useState<boolean>(false);
  const [quickCompressModalOpen, setQuickCompressModalOpen] = useState<boolean>(false);

  // Advanced Export, Compression & Share System State
  const [compressionPreset, setCompressionPreset] = useState<CompressionPreset>('medium'); // Default: Medium Compress (Balanced - 70%)
  const [exportFormatSelection, setExportFormatSelection] = useState<ExportFileFormat>('PDF');
  const [pageExportMode, setPageExportMode] = useState<PageExportMode>('merged');
  const [savedFeedback, setSavedFeedback] = useState<SavedLocationFeedback | null>(null);
  const [currentResultBlob, setCurrentResultBlob] = useState<Blob | null>(null);
  const [currentResultMime, setCurrentResultMime] = useState<string>('application/pdf');
  const [isExportingAction, setIsExportingAction] = useState<boolean>(false);
  const [isCompressionHighlighted, setIsCompressionHighlighted] = useState<boolean>(false);
  const compressionSectionRef = useRef<HTMLDivElement>(null);

  // Targets for export (all pages or selected pages)
  const targetPages = useMemo(() => {
    return isSelectMode && selectedIds.size > 0
      ? capturedPages.filter((p) => selectedIds.has(p.id))
      : capturedPages;
  }, [capturedPages, isSelectMode, selectedIds]);

  // Live real-time estimated file sizes for all 3 compression presets
  const liveEstimates = useMemo(() => {
    return calculateLiveEstimates(
      targetPages.length || 1,
      exportFormatSelection,
      pageExportMode
    );
  }, [targetPages.length, exportFormatSelection, pageExportMode]);

  // Currently selected preset estimate
  const currentEstimate = useMemo(() => {
    if (compressionPreset === 'original') return liveEstimates.original;
    if (compressionPreset === 'medium') return liveEstimates.medium;
    return liveEstimates.extreme;
  }, [compressionPreset, liveEstimates]);


  // Stop camera helper that safely cleans up tracks
  const stopCameraTracks = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // Ignore errors
        }
      });
      streamRef.current = null;
    }
    setStream(null);
    setActiveTrack(null);
    setIsFlashOn(false);
  }, []);

  const stopCamera = useCallback(() => {
    stopCameraTracks();
    setUiStep('gallery');
  }, [stopCameraTracks]);

  // Process incoming image (from Camera, File Upload, or Android Bridge)
  const processImage = useCallback(
    async (imageSrc: string, knownWidth?: number, knownHeight?: number, customName?: string) => {
      if (!imageSrc) return;

      // If dimensions are already known (e.g. direct canvas capture), add page immediately without image reload!
      if (knownWidth && knownHeight && knownWidth > 0 && knownHeight > 0) {
        pageCounterRef.current += 1;
        const newPage: CapturedPage = {
          rawOriginal: imageSrc,
          original: imageSrc,
          processed: imageSrc,
          filter: 'none',
          id: generateId(),
          name: customName || `Page ${pageCounterRef.current}`,
          date: new Date().toLocaleDateString('en-GB'),
          width: knownWidth,
          height: knownHeight,
        };
        setCapturedPages((prev) => [...prev, newPage]);
        setState({ status: 'idle', progress: 0 });
        if (!isAutoMode) {
          stopCamera();
        }
        return;
      }

      setState({ status: 'processing', progress: 40, message: 'Processing Document...' });

      try {
        const img = await loadImageSafely(imageSrc, 5000);
        let finalCanvas: HTMLCanvasElement | null = null;

        // Safe paper extraction only if jscanify and OpenCV are cleanly loaded
        if (isAutoMode && scannerRef.current && (window as any).cv) {
          try {
            const w = img.naturalWidth || img.width;
            const h = img.naturalHeight || img.height;
            if (w > 0 && h > 0) {
              finalCanvas = scannerRef.current.extractPaper(img, w, h);
            }
          } catch (e) {
            console.warn('Auto extraction failed, falling back to clean canvas', e);
          }
        }

        if (!finalCanvas) {
          finalCanvas = drawImageToFreshCanvas(img);
        }

        const processedData = finalCanvas.toDataURL('image/jpeg', 0.92);
        pageCounterRef.current += 1;
        const newPage: CapturedPage = {
          rawOriginal: imageSrc,
          original: processedData,
          processed: processedData,
          filter: 'none',
          id: generateId(),
          name: customName || `Page ${pageCounterRef.current}`,
          date: new Date().toLocaleDateString('en-GB'),
          width: finalCanvas.width || img.naturalWidth || img.width,
          height: finalCanvas.height || img.naturalHeight || img.height,
        };

        setCapturedPages((prev) => [...prev, newPage]);
      } catch (err) {
        console.warn('[Scan] Image load error or fallback recovery:', err);
        pageCounterRef.current += 1;
        const fallbackPage: CapturedPage = {
          rawOriginal: imageSrc,
          original: imageSrc,
          processed: imageSrc,
          filter: 'none',
          id: generateId(),
          name: customName || `Page ${pageCounterRef.current}`,
          date: new Date().toLocaleDateString('en-GB'),
          width: 1200,
          height: 1600,
        };
        setCapturedPages((prev) => [...prev, fallbackPage]);
      } finally {
        setState({ status: 'idle', progress: 0 });
        if (!isAutoMode) {
          stopCamera();
        }
      }
    },
    [isAutoMode, stopCamera]
  );

  // Keep a ref to processImage so window callbacks never use a stale closure
  const processImageRef = useRef(processImage);
  useEffect(() => {
    processImageRef.current = processImage;
  }, [processImage]);

  useEffect(() => {
    if (typeof jscanify !== 'undefined') {
      try {
        scannerRef.current = new jscanify();
      } catch (e) {
        console.warn('Failed to initialize jscanify:', e);
      }
    }

    // Ingest scans from native Android ML Kit Document Scanner:
    // Supports single string, array of strings, or JSON-stringified payloads
    const handleIncomingScans = (payload: any) => {
      console.log("Scanned File URI:", payload);
      if (!payload) return;
      try {
        let scans: string[] = [];
        if (Array.isArray(payload)) {
          scans = payload;
        } else if (typeof payload === 'string') {
          const trimmed = payload.trim();
          if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
            try {
              const parsed = JSON.parse(trimmed);
              if (Array.isArray(parsed)) {
                scans = parsed;
              } else if (parsed.pages && Array.isArray(parsed.pages)) {
                scans = parsed.pages;
              } else if (parsed.images && Array.isArray(parsed.images)) {
                scans = parsed.images;
              } else if (parsed.image || parsed.base64) {
                scans = [parsed.image || parsed.base64];
              } else {
                scans = [trimmed];
              }
            } catch {
              scans = [trimmed];
            }
          } else {
            scans = [trimmed];
          }
        }

        scans.forEach((imgData) => {
          if (typeof imgData === 'string' && imgData.trim().length > 0) {
            const trimmed = imgData.trim();
            if (
              trimmed.startsWith('content:') ||
              trimmed.startsWith('file:') ||
              trimmed.startsWith('http:') ||
              trimmed.startsWith('https:') ||
              trimmed.startsWith('blob:')
            ) {
              processImageRef.current(trimmed);
            } else {
              const formatted = trimmed.startsWith('data:image')
                ? trimmed
                : `data:image/jpeg;base64,${trimmed}`;
              processImageRef.current(formatted);
            }
          }
        });
        setUiStep('gallery');
      } catch (err) {
        console.error('[Scan] Error handling incoming scans from Android:', err);
      }
    };

    // Check for pending scan payload cached in sessionStorage from App.tsx
    try {
      const pending = sessionStorage.getItem('pending_scan_payload');
      if (pending) {
        sessionStorage.removeItem('pending_scan_payload');
        handleIncomingScans(pending);
      }
    } catch {
      // Ignore
    }

    const onCustomScanEvent = (e: any) => {
      if (e.detail) {
        handleIncomingScans(e.detail);
      }
    };
    window.addEventListener('android_scan_received', onCustomScanEvent);

    (window as any).onScanComplete = handleIncomingScans;
    (window as any).onScanBatchComplete = handleIncomingScans;
    (window as any).onDocumentScanResult = handleIncomingScans;

    // Listen for file saved confirmation callback from Android WebView:
    const handleFileSaved = (savedPath: string, fileName: string, mimeType: string) => {
      console.log('[onFileSaved] Received callback from Android:', savedPath, fileName, mimeType);
      setSavedFeedback((prev) => ({
        visible: true,
        fileName: fileName || prev?.fileName || 'Document.pdf',
        savedPath: savedPath || 'Internal Storage > Downloads > PixelPro_Scans',
        mimeType: mimeType || prev?.mimeType || 'application/pdf',
        fileSizeText: prev?.fileSizeText,
        blobUrl: prev?.blobUrl,
        blob: prev?.blob,
        timestamp: Date.now(),
      }));
      setHasDownloaded(true);
    };
    (window as any).onFileSaved = handleFileSaved;


    return () => {
      stopCameraTracks();
      window.removeEventListener('android_scan_received', onCustomScanEvent);
    };
  }, [stopCameraTracks]);

  // Attach stream to video element when in camera step
  useEffect(() => {
    if (uiStep === 'camera' && stream && videoRef.current) {
      videoRef.current.srcObject = stream;
    }
  }, [uiStep, stream]);

  // Hide banner ad during fullscreen camera, show in gallery/preview
  useEffect(() => {
    if (uiStep === 'camera') {
      hideBannerAd();
    } else {
      showBannerAd('/scan');
    }
  }, [uiStep]);

  // Revoke object URL on replacement or unmount
  useEffect(() => {
    return () => {
      if (state.resultUrl) {
        try {
          URL.revokeObjectURL(state.resultUrl);
        } catch {
          // Ignore
        }
      }
    };
  }, [state.resultUrl]);

  // Reset crop state when switching preview pages
  useEffect(() => {
    if (previewPage) {
      setIsCropping(false);
      setCrop({ x: 0, y: 0 });
      setZoom(1);
      setCroppedAreaPixels(null);
    }
  }, [previewPage?.id]);

  // Torch / Flash effect
  useEffect(() => {
    if (!activeTrack) return;
    try {
      const caps = activeTrack.getCapabilities ? activeTrack.getCapabilities() : ({} as any);
      if ((caps as any).torch) {
        activeTrack
          .applyConstraints({
            advanced: [{ torch: isFlashOn }],
          } as any)
          .catch((err) => console.error('Flash error:', err));
      }
    } catch (err) {
      console.warn('Torch not supported on this device:', err);
    }
  }, [isFlashOn, activeTrack]);

  const setResult = (blob: Blob, filename: string) => {
    setCurrentResultBlob(blob);
    setCurrentResultMime(blob.type || (filename.toLowerCase().endsWith('.zip') ? 'application/zip' : filename.toLowerCase().endsWith('.png') ? 'image/png' : filename.toLowerCase().endsWith('.jpg') ? 'image/jpeg' : 'application/pdf'));
    setState((prev) => {
      if (prev.resultUrl) {
        try {
          URL.revokeObjectURL(prev.resultUrl);
        } catch {
          // Ignore
        }
      }
      return {
        status: 'success',
        resultUrl: URL.createObjectURL(blob),
        resultFileName: filename,
        progress: 100,
      };
    });
  };

  const startCamera = async () => {
    // 1. Check if running inside the Android WebView:
    const isAndroidApp =
      typeof window !== 'undefined' &&
      Boolean((window as any).AndroidScanner || (window as any).AndroidBridge);

    if (isAndroidApp) {
      // DO NOT open the web camera screen. Immediately call AndroidScanner.startScan() or AndroidBridge.startDocumentScan()
      if (
        (window as any).AndroidBridge &&
        typeof (window as any).AndroidBridge.startDocumentScan === 'function'
      ) {
        (window as any).AndroidBridge.startDocumentScan();
      } else if (
        (window as any).AndroidScanner &&
        typeof (window as any).AndroidScanner.startScan === 'function'
      ) {
        (window as any).AndroidScanner.startScan();
      } else if (
        (window as any).AndroidBridge &&
        typeof (window as any).AndroidBridge.startScan === 'function'
      ) {
        (window as any).AndroidBridge.startScan();
      }
      return;
    }

    // 2. Only fallback to HTML5 Web Camera UI if running in a normal browser
    try {
      stopCameraTracks();
      setState({ status: 'loading', progress: 0, message: 'Waking up camera...' });

      let mediaStream: MediaStream;
      try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          },
          audio: false,
        });
      } catch {
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
          audio: false,
        });
      }

      streamRef.current = mediaStream;
      setStream(mediaStream);
      setActiveTrack(mediaStream.getVideoTracks()[0] || null);
      setUiStep('camera');
      setState({ status: 'idle', progress: 0 });
    } catch (err) {
      console.error(err);
      setState({
        status: 'error',
        progress: 0,
        message: 'Camera access failed. Please allow camera permission or upload from gallery.',
      });
    }
  };

  const handleBack = () => {
    if (uiStep === 'preview') {
      setIsCropping(false);
      setUiStep('gallery');
    } else if (uiStep === 'camera') {
      stopCamera();
    } else {
      if (window.history.length > 1) {
        navigate(-1);
      } else {
        navigate('/');
      }
    }
  };

  const handleRenamePage = (pageId: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed) return;
    setCapturedPages((prev) =>
      prev.map((p) => (p.id === pageId ? { ...p, name: trimmed } : p))
    );
    if (previewPage?.id === pageId) {
      setPreviewPage((prev) => (prev ? { ...prev, name: trimmed } : null));
    }
    if (selectedMenuPage?.id === pageId) {
      setSelectedMenuPage((prev) => (prev ? { ...prev, name: trimmed } : null));
    }
  };

  const handleMovePage = (pageId: string, direction: 'left' | 'right') => {
    setCapturedPages((prev) => {
      const idx = prev.findIndex((p) => p.id === pageId);
      if (idx === -1) return prev;
      const targetIdx = direction === 'left' ? idx - 1 : idx + 1;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;
      const copy = [...prev];
      const [moved] = copy.splice(idx, 1);
      copy.splice(targetIdx, 0, moved);
      return copy;
    });
  };

  // Rotate both base original and processed image so active filters aren't lost
  const handleRotatePage = async (pageId: string) => {
    const targetPage = capturedPages.find((p) => p.id === pageId);
    if (!targetPage) return;

    setState({ status: 'processing', progress: 50, message: 'Rotating Page...' });

    const rotateDataUrl = async (src: string): Promise<{ url: string; w: number; h: number }> => {
      try {
        const img = await loadImageSafely(src, 5000);
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalHeight || img.height;
        canvas.height = img.naturalWidth || img.width;
        const ctx = canvas.getContext('2d');
        if (!ctx) return { url: src, w: canvas.width, h: canvas.height };
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((90 * Math.PI) / 180);
        ctx.drawImage(img, -(img.naturalWidth || img.width) / 2, -(img.naturalHeight || img.height) / 2);
        return {
          url: canvas.toDataURL('image/jpeg', 0.92),
          w: canvas.width,
          h: canvas.height,
        };
      } catch (err) {
        console.warn('Rotate error, keeping original image:', err);
        return { url: src, w: targetPage.width, h: targetPage.height };
      }
    };

    try {
      const [rotOrig, rotProc] = await Promise.all([
        rotateDataUrl(targetPage.original),
        rotateDataUrl(targetPage.processed),
      ]);

      setCapturedPages((prev) =>
        prev.map((p) =>
          p.id === pageId
            ? {
                ...p,
                original: rotOrig.url,
                processed: rotProc.url,
                width: rotProc.w,
                height: rotProc.h,
              }
            : p
        )
      );
      if (previewPage?.id === pageId) {
        setPreviewPage((prev) =>
          prev
            ? {
                ...prev,
                original: rotOrig.url,
                processed: rotProc.url,
                width: rotProc.w,
                height: rotProc.h,
              }
            : null
        );
      }
      if (selectedMenuPage?.id === pageId) {
        setSelectedMenuPage((prev) =>
          prev ? { ...prev, original: rotOrig.url, processed: rotProc.url } : null
        );
      }
    } catch (e) {
      console.error('Failed to rotate page:', e);
    } finally {
      setState({ status: 'idle', progress: 0 });
    }
  };

  const handleExportSinglePage = async (page: CapturedPage, format: 'PDF' | 'JPG') => {
    try {
      if (format === 'JPG') {
        await downloadFileWithAd(page.processed, `${page.name.replace(/\s+/g, '_')}.jpg`);
      } else {
        const jspdfLib = (window as any).jspdf;
        const jsPDF = jspdfLib?.jsPDF || jspdfLib || (window as any).jsPDF;
        if (!jsPDF) {
          alert('PDF engine is loading. Please try again.');
          return;
        }
        const doc = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' });
        addImageFitted(doc, page);
        const blob = doc.output('blob');
        const url = URL.createObjectURL(blob);
        await downloadFileWithAd(url, `${page.name.replace(/\s+/g, '_')}.pdf`);
        setTimeout(() => {
          try {
            URL.revokeObjectURL(url);
          } catch {}
        }, 5000);
      }
    } catch (err) {
      console.error('Export single page error:', err);
    }
  };

  // Supports selecting multiple images at once, read sequentially to preserve order
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileList = Array.from(files) as File[];
    e.target.value = '';

    const readSequentially = async () => {
      setState({ status: 'processing', progress: 20, message: 'Reading uploaded files...' });
      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        const dataUrl = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve((reader.result as string) || '');
          reader.onerror = () => resolve('');
          reader.readAsDataURL(file);
        });
        if (dataUrl) {
          await processImage(dataUrl);
        }
      }
      setState({ status: 'idle', progress: 0 });
    };

    readSequentially().catch((err) => {
      console.error('File upload error:', err);
      setState({ status: 'idle', progress: 0 });
    });
  };

  /**
   * Universal multi-file picker handler:
   * Accepts PDF, DOCX, TXT, and Image files.
   * Copies each picked file into the project, extracts pages if PDF,
   * adds them to the Documents list, and updates the DOCUMENTS (n) count.
   */
  const handleAllFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const fileList = Array.from(files) as File[];
    e.target.value = '';

    setState({ status: 'processing', progress: 10, message: 'Adding files to project...' });

    try {
      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        const baseName = file.name.replace(/\.[^/.]+$/, '');
        const ext = file.name.split('.').pop()?.toLowerCase() || '';

        // 1. PDF Document: Extract and render each page via pdf.js
        if (file.type === 'application/pdf' || ext === 'pdf') {
          setState({
            status: 'processing',
            progress: Math.round(((i + 0.3) / fileList.length) * 80),
            message: `Extracting pages from ${file.name}...`,
          });

          try {
            const arrayBuffer = await file.arrayBuffer();
            const win = window as any;
            const pdfjs = win.pdfjsLib;

            if (pdfjs) {
              if (!pdfjs.GlobalWorkerOptions?.workerSrc) {
                pdfjs.GlobalWorkerOptions.workerSrc =
                  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
              }
              const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
              const pdfDoc = await loadingTask.promise;
              const numPages = pdfDoc.numPages;

              for (let pNum = 1; pNum <= numPages; pNum++) {
                const page = await pdfDoc.getPage(pNum);
                const viewport = page.getViewport({ scale: 1.5 });
                const canvas = document.createElement('canvas');
                canvas.width = viewport.width;
                canvas.height = viewport.height;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                  await page.render({ canvasContext: ctx, viewport }).promise;
                  const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
                  pageCounterRef.current += 1;
                  const newPage: CapturedPage = {
                    rawOriginal: dataUrl,
                    original: dataUrl,
                    processed: dataUrl,
                    filter: 'none',
                    id: generateId(),
                    name: numPages > 1 ? `${baseName} (P${pNum})` : baseName,
                    date: new Date().toLocaleDateString('en-GB'),
                    width: viewport.width,
                    height: viewport.height,
                  };
                  setCapturedPages((prev) => [...prev, newPage]);
                }
              }
            } else {
              throw new Error('PDF library not ready');
            }
          } catch (pdfErr) {
            console.warn('PDF page extract fallback:', pdfErr);
            const canvas = document.createElement('canvas');
            canvas.width = 1240;
            canvas.height = 1754;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(0, 0, 1240, 1754);
              ctx.fillStyle = '#14b8a6';
              ctx.font = 'bold 50px sans-serif';
              ctx.fillText('PDF DOCUMENT', 100, 200);
              ctx.fillStyle = '#ffffff';
              ctx.font = '34px sans-serif';
              ctx.fillText(file.name, 100, 280);
              ctx.fillStyle = '#94a3b8';
              ctx.font = '24px sans-serif';
              ctx.fillText(`Size: ${(file.size / 1024).toFixed(1)} KB`, 100, 340);
              const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
              pageCounterRef.current += 1;
              setCapturedPages((prev) => [
                ...prev,
                {
                  rawOriginal: dataUrl,
                  original: dataUrl,
                  processed: dataUrl,
                  filter: 'none',
                  id: generateId(),
                  name: baseName,
                  date: new Date().toLocaleDateString('en-GB'),
                  width: 1240,
                  height: 1754,
                },
              ]);
            }
          }
        }
        // 2. Images: JPG, PNG, WEBP
        else if (file.type.startsWith('image/')) {
          const dataUrl = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve((reader.result as string) || '');
            reader.onerror = () => resolve('');
            reader.readAsDataURL(file);
          });
          if (dataUrl) {
            await processImage(dataUrl, undefined, undefined, baseName);
          }
        }
        // 3. Plain Text File (.txt)
        else if (file.type.startsWith('text/') || ext === 'txt') {
          const text = await file.text();
          const canvas = document.createElement('canvas');
          canvas.width = 1240;
          canvas.height = 1754;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#0f172a';
            ctx.font = 'bold 36px sans-serif';
            ctx.fillText(file.name, 80, 100);
            ctx.strokeStyle = '#e2e8f0';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(80, 120);
            ctx.lineTo(canvas.width - 80, 120);
            ctx.stroke();

            ctx.fillStyle = '#334155';
            ctx.font = '22px monospace';
            const lines = text.split('\n');
            let y = 170;
            for (let l = 0; l < lines.length && y < canvas.height - 80; l++) {
              ctx.fillText(lines[l].substring(0, 80), 80, y);
              y += 32;
            }
            const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
            pageCounterRef.current += 1;
            setCapturedPages((prev) => [
              ...prev,
              {
                rawOriginal: dataUrl,
                original: dataUrl,
                processed: dataUrl,
                filter: 'none',
                id: generateId(),
                name: baseName,
                date: new Date().toLocaleDateString('en-GB'),
                width: canvas.width,
                height: canvas.height,
              },
            ]);
          }
        }
        // 4. DOCX, DOC and other document files
        else {
          const canvas = document.createElement('canvas');
          canvas.width = 1240;
          canvas.height = 1754;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#38bdf8';
            ctx.font = 'bold 44px sans-serif';
            ctx.fillText('DOCUMENT ATTACHMENT', 80, 140);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 32px sans-serif';
            ctx.fillText(file.name, 80, 220);
            ctx.fillStyle = '#94a3b8';
            ctx.font = '24px sans-serif';
            ctx.fillText(`File type: ${file.type || ext.toUpperCase()} • ${(file.size / 1024).toFixed(1)} KB`, 80, 280);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
            pageCounterRef.current += 1;
            setCapturedPages((prev) => [
              ...prev,
              {
                rawOriginal: dataUrl,
                original: dataUrl,
                processed: dataUrl,
                filter: 'none',
                id: generateId(),
                name: baseName,
                date: new Date().toLocaleDateString('en-GB'),
                width: canvas.width,
                height: canvas.height,
              },
            ]);
          }
        }
      }
      showSnackbar(`Added ${fileList.length} file(s) to project.`);
    } catch (err: any) {
      console.error('File import error:', err);
      showSnackbar('Error reading some files. Please retry.');
    } finally {
      setState({ status: 'idle', progress: 0 });
    }
  };

  const handleTouchStart = (pageId: string) => {
    if (isSelectMode) return;
    longPressTimerRef.current = setTimeout(() => {
      setIsSelectMode(true);
      setSelectedIds(new Set([pageId]));
      try {
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          navigator.vibrate(50);
        }
      } catch {}
    }, 450);
  };

  const handleTouchEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!video.videoWidth || !video.videoHeight) return;

    // Trigger visual shutter flash
    setShutterFlash(true);
    setTimeout(() => setShutterFlash(false), 150);

    // Haptic vibration feedback on supported mobile devices
    try {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(50);
      }
    } catch {
      // Ignore vibration error
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);

    const rawData = canvas.toDataURL('image/jpeg', 0.95);
    processImage(rawData, canvas.width, canvas.height);

    setCaptureNotice(`Page ${pageCounterRef.current + 1} Captured!`);
    setTimeout(() => setCaptureNotice(null), 1800);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleDragStart = (index: number) => {
    dragItemIndex.current = index;
  };
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };
  const handleDrop = (index: number) => {
    const from = dragItemIndex.current;
    dragItemIndex.current = null;
    if (from === null || from === index) return;
    setCapturedPages((prev) => {
      const updated = [...prev];
      const [moved] = updated.splice(from, 1);
      updated.splice(index, 0, moved);
      return updated;
    });
  };

  const onCropComplete = useCallback((_croppedArea: any, croppedPixels: any) => {
    setCroppedAreaPixels(croppedPixels);
  }, []);

  // Apply filter and/or crop without losing previous crops
  const applyFilterAndCrop = async (
    pageId: string,
    filter: ScanFilter,
    doCrop: boolean = false
  ) => {
    const page = capturedPages.find((p) => p.id === pageId);
    if (!page) return;

    setState({ status: 'processing', progress: 50, message: 'Applying changes...' });

    try {
      const img = await loadImageSafely(page.original, 5000);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setState({ status: 'idle', progress: 0 });
        return;
      }

      let nextBaseOriginal = page.original;

      // Ensure croppedAreaPixels has fallback to full image if doCrop is true but area wasn't dragged
      const cropArea = croppedAreaPixels || {
        x: 0,
        y: 0,
        width: img.naturalWidth || img.width,
        height: img.naturalHeight || img.height,
      };

      if (doCrop && cropArea && cropArea.width > 0 && cropArea.height > 0) {
        canvas.width = Math.max(10, Math.round(cropArea.width));
        canvas.height = Math.max(10, Math.round(cropArea.height));
        ctx.drawImage(
          img,
          cropArea.x,
          cropArea.y,
          cropArea.width,
          cropArea.height,
          0,
          0,
          canvas.width,
          canvas.height
        );
        // Save cropped base image so subsequent filter changes don't undo the crop
        nextBaseOriginal = canvas.toDataURL('image/jpeg', 0.92);
      } else {
        canvas.width = img.naturalWidth || img.width;
        canvas.height = img.naturalHeight || img.height;
        ctx.drawImage(img, 0, 0);
      }

      applyPixelFilterToCanvas(ctx, canvas.width, canvas.height, filter);

      const processedData = canvas.toDataURL('image/jpeg', 0.9);
      const { width, height } = canvas;

      setCapturedPages((prev) =>
        prev.map((p) =>
          p.id === pageId
            ? {
                ...p,
                original: nextBaseOriginal,
                processed: processedData,
                filter,
                width,
                height,
              }
            : p
        )
      );

      if (previewPage?.id === pageId) {
        setPreviewPage((prev) =>
          prev
            ? {
                ...prev,
                original: nextBaseOriginal,
                processed: processedData,
                filter,
                width,
                height,
              }
            : null
        );
      }
    } catch (err) {
      console.error('[Scan] Error applying filter or crop:', err);
    } finally {
      setState({ status: 'idle', progress: 0 });
      setIsCropping(false);
    }
  };

  // Restore page back to uncropped, unfiltered original
  const handleResetPageToRaw = async (pageId: string) => {
    const page = capturedPages.find((p) => p.id === pageId);
    if (!page) return;

    try {
      const img = await loadImageSafely(page.rawOriginal, 5000);
      const width = img.naturalWidth || img.width || 1200;
      const height = img.naturalHeight || img.height || 1600;

      setCapturedPages((prev) =>
        prev.map((p) =>
          p.id === pageId
            ? {
                ...p,
                original: p.rawOriginal,
                processed: p.rawOriginal,
                filter: 'none',
                width,
                height,
              }
            : p
        )
      );
      if (previewPage?.id === pageId) {
        setPreviewPage((prev) =>
          prev
            ? {
                ...prev,
                original: prev.rawOriginal,
                processed: prev.rawOriginal,
                filter: 'none',
                width,
                height,
              }
            : null
        );
      }
    } catch (e) {
      console.warn('Failed to reset image dimensions:', e);
    } finally {
      setIsCropping(false);
    }
  };

  const runOCR = async (targets: CapturedPage[]): Promise<string> => {
    let combinedText = '';
    for (let i = 0; i < targets.length; i++) {
      const page = targets[i];
      setState({
        status: 'processing',
        progress: Math.round(((i + 1) / targets.length) * 90),
        message: `Scanning text with Google AI (${i + 1}/${targets.length})...`,
      });
      try {
        const result = await scanImageWithGoogleAI(page.processed, { mode: 'ocr' });
        if (result.success && (result.extractedText || result.summary)) {
          combinedText += `=========================================================\n`;
          combinedText += `PAGE ${i + 1}: ${page.name}\n`;
          if (result.documentType) combinedText += `Document Type: ${result.documentType}\n`;
          if (result.language) combinedText += `Language: ${result.language}\n`;
          if (result.summary) combinedText += `Summary: ${result.summary}\n`;
          if (result.fields && Object.values(result.fields).some(Boolean)) {
            combinedText += `\nKey Extracted Details:\n`;
            if (result.fields.name) combinedText += `  Name: ${result.fields.name}\n`;
            if (result.fields.idNumber) combinedText += `  ID Number: ${result.fields.idNumber}\n`;
            if (result.fields.dobOrYob) combinedText += `  DOB/YOB: ${result.fields.dobOrYob}\n`;
            if (result.fields.gender) combinedText += `  Gender: ${result.fields.gender}\n`;
            if (result.fields.fatherOrHusbandName) combinedText += `  Father/Husband: ${result.fields.fatherOrHusbandName}\n`;
            if (result.fields.address) combinedText += `  Address: ${result.fields.address}\n`;
          }
          combinedText += `\nExtracted Text:\n`;
          combinedText += `${(result.extractedText || '').trim()}\n`;
          combinedText += `=========================================================\n\n`;
        } else {
          combinedText += `--- Page ${i + 1}: ${page.name} ---\n${result.summary || '[No text detected on page]'}\n\n`;
        }
      } catch (e) {
        console.error('Google AI scan failed for', page.name, e);
        combinedText += `--- Page ${i + 1}: ${page.name} ---\n[Google AI scan failed for this page]\n\n`;
      }
    }
    return combinedText;
  };

  const finalizeExport = async (
    mainBlob: Blob,
    mainFilename: string,
    targets: CapturedPage[]
  ) => {
    if (!enableOCR) {
      setResult(mainBlob, mainFilename);
      return;
    }
    const text = await runOCR(targets);
    const zip = new JSZip();
    zip.file(mainFilename, mainBlob);
    zip.file(`${folderName}_Google_AI_OCR.txt`, text);
    setState({ status: 'processing', progress: 95, message: 'Packaging results...' });
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    setResult(zipBlob, `${folderName}_with_Google_OCR.zip`);
  };

  const handleExport = async () => {
    setHasDownloaded(false);
    const targets = isSelectMode
      ? capturedPages.filter((p) => selectedIds.has(p.id))
      : capturedPages;

    if (targets.length === 0) return;

    if (enablePassword && !pdfPassword.trim() && exportFormat === 'PDF') {
      setState({
        status: 'error',
        progress: 0,
        message: 'Password protection is enabled, but password is empty. Please enter a password or disable the password toggle.',
      });
      return;
    }

    setState({
      status: 'processing',
      progress: 10,
      message: exportFormat === 'PDF' ? 'Building PDF...' : 'Preparing images...',
    });

    try {
      if (exportFormat === 'JPG') {
        if (targets.length === 1 && !saveSeparately) {
          const res = await fetch(targets[0].processed);
          const blob = await res.blob();
          await finalizeExport(
            blob,
            `${targets[0].name.replace(/\s+/g, '_')}.jpg`,
            targets
          );
        } else {
          const JSZipLib = (window as any).JSZip;
          if (!JSZipLib) throw new Error('Zip library is loading. Please retry.');
          const zip = new JSZipLib();
          for (let i = 0; i < targets.length; i++) {
            const page = targets[i];
            const res = await fetch(page.processed);
            const blob = await res.blob();
            zip.file(`${page.name.replace(/\s+/g, '_')}.jpg`, blob);
            setState({
              status: 'processing',
              progress: Math.round(((i + 1) / targets.length) * 90),
              message: `Adding ${page.name}...`,
            });
          }
          if (enableOCR) {
            const text = await runOCR(targets);
            zip.file(`${folderName}_Google_AI_OCR.txt`, text);
          }
          const zipBlob = await zip.generateAsync({ type: 'blob' });
          setResult(zipBlob, `${folderName}.zip`);
        }
      } else {
        const jspdfLib = (window as any).jspdf;
        const jsPDF = jspdfLib?.jsPDF || jspdfLib || (window as any).jsPDF;
        if (!jsPDF) {
          throw new Error('PDF generator engine (jsPDF) is loading. Please retry.');
        }

        const pdfOptions: any = { orientation: 'p', unit: 'mm', format: 'a4' };
        if (enablePassword && pdfPassword.trim()) {
          pdfOptions.encryption = {
            userPassword: pdfPassword.trim(),
            ownerPassword: pdfPassword.trim(),
            userPermissions: ['print', 'modify', 'copy', 'annot-forms'],
          };
        }

        if (saveSeparately) {
          const zip = new JSZip();
          for (let i = 0; i < targets.length; i++) {
            const page = targets[i];
            const doc = new jsPDF(pdfOptions);
            addImageFitted(doc, page);
            const pdfBlob = doc.output('blob');
            zip.file(`${page.name.replace(/\s+/g, '_')}.pdf`, pdfBlob);
            setState({
              status: 'processing',
              progress: 30 + Math.round(((i + 1) / targets.length) * 60),
              message: `Zipping ${page.name}...`,
            });
          }
          if (enableOCR) {
            const text = await runOCR(targets);
            zip.file(`${folderName}_Google_AI_OCR.txt`, text);
          }
          const zipBlob = await zip.generateAsync({ type: 'blob' });
          setResult(zipBlob, `${folderName}.zip`);
        } else {
          const doc = new jsPDF(pdfOptions);
          for (let i = 0; i < targets.length; i++) {
            if (i > 0) doc.addPage();
            addImageFitted(doc, targets[i]);
            setState({
              status: 'processing',
              progress: Math.round(((i + 1) / targets.length) * 90),
              message: `Adding ${targets[i].name}...`,
            });
          }
          const blob = doc.output('blob');
          await finalizeExport(blob, `${folderName}.pdf`, targets);
        }
      }
      setShowShareModal(false);
    } catch (e) {
      console.error(e);
      setState({
        status: 'error',
        progress: 0,
        message: 'Export failed. Please try again.',
      });
    }
  };

  /**
   * Dedicated PDF/Multi-format generation and download handler.
   * Uses selected compression preset ('original', 'medium', 'extreme') and format.
   * Handles saving/downloading reliably in both Android WebView and normal browsers,
   * with immediate saved location feedback.
   */
  const downloadDocument = async (
    overridePreset?: CompressionPreset,
    overrideFormat?: ExportFileFormat
  ) => {
    if (capturedPages.length === 0) {
      setState({
        status: 'error',
        progress: 0,
        message: 'No scanned pages available. Please scan or upload documents first.',
      });
      return;
    }

    const targets =
      isSelectMode && selectedIds.size > 0
        ? capturedPages.filter((p) => selectedIds.has(p.id))
        : capturedPages;

    const presetToUse = overridePreset || compressionPreset || 'medium';
    const formatToUse = overrideFormat || exportFormatSelection || 'PDF';

    setState({
      status: 'processing',
      progress: 15,
      message: `Compiling ${formatToUse} (${presetToUse} compression)...`,
    });

    try {
      const bundle = await buildExportBundle({
        pages: targets,
        format: formatToUse,
        compression: presetToUse,
        mode: pageExportMode,
        folderName: folderName || 'Scan_Document',
        password: enablePassword && pdfPassword.trim() ? pdfPassword.trim() : undefined,
        onProgress: (pct, msg) => {
          setState({
            status: 'processing',
            progress: pct,
            message: msg,
          });
        },
      });

      const blobUrl = URL.createObjectURL(bundle.blob);
      setCurrentResultBlob(bundle.blob);
      setCurrentResultMime(bundle.mimeType);

      // 1. Android WebView Native Bridge Save:
      const win = window as any;
      if (win.AndroidBridge) {
        try {
          const reader = new FileReader();
          reader.readAsDataURL(bundle.blob);
          reader.onloadend = () => {
            const base64Data = reader.result as string;
            if (typeof win.AndroidBridge.downloadFile === 'function') {
              win.AndroidBridge.downloadFile(base64Data, bundle.fileName);
            } else if (typeof win.AndroidBridge.shareFile === 'function') {
              win.AndroidBridge.shareFile(base64Data, bundle.fileName);
            }
          };
        } catch (bridgeErr) {
          console.warn('[Scan] Bridge file transfer failed:', bridgeErr);
        }
      }

      // 2. Browser download with ad flow
      await downloadFileWithAd(blobUrl, bundle.fileName);

      // 3. Set Saved Location Feedback
      const isApp = isAndroidBridgeAvailable();
      const defaultPath = isApp
        ? `Internal Storage > Downloads > PixelPro_Scans / ${bundle.fileName}`
        : `Browser Downloads > ${bundle.fileName}`;

      setSavedFeedback({
        visible: true,
        fileName: bundle.fileName,
        savedPath: defaultPath,
        mimeType: bundle.mimeType,
        fileSizeText: bundle.formattedSize,
        blobUrl: blobUrl,
        blob: bundle.blob,
        timestamp: Date.now(),
      });

      // 4. Update success screen state with downloaded file
      setResult(bundle.blob, bundle.fileName);
      setHasDownloaded(true);
    } catch (err: any) {
      console.error('Failed to export document:', err);
      setState({
        status: 'error',
        progress: 0,
        message: err?.message || 'Failed to download document. Please retry.',
      });
    }
  };

  /**
   * Dedicated file share handler using the active format, compression, and mode.
   */
  const shareDocument = async () => {
    if (capturedPages.length === 0) return;

    const targets =
      isSelectMode && selectedIds.size > 0
        ? capturedPages.filter((p) => selectedIds.has(p.id))
        : capturedPages;

    setState({
      status: 'processing',
      progress: 20,
      message: `Packaging ${exportFormatSelection} (${compressionPreset} compression) for sharing...`,
    });

    try {
      const bundle = await buildExportBundle({
        pages: targets,
        format: exportFormatSelection,
        compression: compressionPreset,
        mode: pageExportMode,
        folderName: folderName || 'Scan_Document',
        password: enablePassword && pdfPassword.trim() ? pdfPassword.trim() : undefined,
        onProgress: (pct, msg) => {
          setState({
            status: 'processing',
            progress: pct,
            message: msg,
          });
        },
      });

      const blobUrl = URL.createObjectURL(bundle.blob);
      setCurrentResultBlob(bundle.blob);
      setCurrentResultMime(bundle.mimeType);

      // Trigger native Android bridge share or Web Share API
      await shareFileViaAndroidBridge(bundle.blob, bundle.fileName);

      setResult(bundle.blob, bundle.fileName);
    } catch (err: any) {
      console.error('Failed to share document:', err);
      setState({
        status: 'error',
        progress: 0,
        message: err?.message || 'Failed to share document. Please retry.',
      });
    }
  };

  const handleExportDownloadAction = async () => {
    if (capturedPages.length === 0) return;
    setIsExportingAction(true);
    await downloadDocument(compressionPreset, exportFormatSelection);
    setIsExportingAction(false);
  };

  const handleExportShareAction = async () => {
    if (capturedPages.length === 0) return;
    setIsExportingAction(true);
    await shareDocument();
    setIsExportingAction(false);
  };

  const handleCompressFocusClick = () => {
    if (compressionSectionRef.current) {
      compressionSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setIsCompressionHighlighted(true);
      setTimeout(() => setIsCompressionHighlighted(false), 2000);
    }
  };


  /**
   * Direct PDF export and download logic.
   * Compiles all scanned documents in the current project into a single PDF,
   * saves to the device's Downloads folder via MediaStore / browser download,
   * and displays a floating Snackbar "Saved to Downloads" with an "OPEN" action.
   */
  const handleDirectDownloadScan = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (capturedPages.length === 0) {
      showSnackbar('No documents to download. Please scan or add files first.');
      return;
    }

    setIsExportingAction(true);
    setState({
      status: 'processing',
      progress: 20,
      message: 'Compiling project documents into single PDF...',
    });

    try {
      const targets =
        isSelectMode && selectedIds.size > 0
          ? capturedPages.filter((p) => selectedIds.has(p.id))
          : capturedPages;

      const bundle = await buildExportBundle({
        pages: targets,
        format: 'PDF',
        compression: compressionPreset || 'medium',
        mode: 'merged',
        folderName: folderName || 'Scan_Project',
        password: enablePassword && pdfPassword.trim() ? pdfPassword.trim() : undefined,
        onProgress: (pct, msg) => {
          setState({
            status: 'processing',
            progress: pct,
            message: msg,
          });
        },
      });

      const blobUrl = URL.createObjectURL(bundle.blob);
      setCurrentResultBlob(bundle.blob);
      setCurrentResultMime('application/pdf');

      // Android WebView Native Bridge Save
      const win = window as any;
      if (win.AndroidBridge) {
        try {
          const reader = new FileReader();
          reader.readAsDataURL(bundle.blob);
          reader.onloadend = () => {
            const base64Data = reader.result as string;
            if (typeof win.AndroidBridge.downloadFile === 'function') {
              win.AndroidBridge.downloadFile(base64Data, bundle.fileName);
            } else if (typeof win.AndroidBridge.shareFile === 'function') {
              win.AndroidBridge.shareFile(base64Data, bundle.fileName);
            }
          };
        } catch (bridgeErr) {
          console.warn('[Scan] Bridge file transfer failed:', bridgeErr);
        }
      }

      // Browser download trigger
      await downloadFileWithAd(blobUrl, bundle.fileName);

      const isApp = isAndroidBridgeAvailable();
      const defaultPath = isApp
        ? `Internal Storage > Downloads > PixelPro_Scans / ${bundle.fileName}`
        : `Browser Downloads > ${bundle.fileName}`;

      setSavedFeedback({
        visible: true,
        fileName: bundle.fileName,
        savedPath: defaultPath,
        mimeType: bundle.mimeType,
        fileSizeText: bundle.formattedSize,
        blobUrl: blobUrl,
        blob: bundle.blob,
        timestamp: Date.now(),
      });

      setResult(bundle.blob, bundle.fileName);
      setHasDownloaded(true);
      setState({ status: 'idle', progress: 0 });

      // Display Snackbar "Saved to Downloads" with "OPEN" action!
      showSnackbar(`Saved to Downloads: ${bundle.fileName}`, 'OPEN', () => {
        openSavedFileSafely(defaultPath, 'application/pdf', blobUrl);
      });
    } catch (err: any) {
      console.error('Direct download scan error:', err);
      setState({
        status: 'error',
        progress: 0,
        message: err?.message || 'Failed to download scan. Please retry.',
      });
      showSnackbar('Failed to download scan. Please try again.');
    } finally {
      setIsExportingAction(false);
    }
  };

  /**
   * Opens the Export Studio screen first without auto-downloading.
   * Lets users inspect the document, format options, and compression presets
   * with live size estimation before explicitly tapping "Download File".
   */
  const handleOpenExportStudio = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (capturedPages.length === 0) {
      showSnackbar('No documents to download. Please scan or add files first.');
      return;
    }

    setHasDownloaded(false);
    setSavedFeedback(null);
    setState({
      status: 'success',
      progress: 100,
      resultFileName: `${folderName || 'Scan_Document'}.${exportFormatSelection.toLowerCase()}`,
    });
  };

  /**
   * Separate click handler for the Download FAB.
   * Opens the Export Studio screen first without auto-downloading.
   */
  const handleDownloadFabClick = (e: React.MouseEvent) => {
    handleOpenExportStudio(e);
  };

  /**
   * Separate click handler for the Camera FAB.
   * Strictly launches camera / native document scanner.
   */
  const handleCameraFabClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    startCamera();
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-[#020617] text-white flex flex-col overflow-hidden h-screen w-screen select-none font-sans">
      <canvas ref={canvasRef} className="hidden" />

      {/* 1. TOP NAVBAR (Gallery Mode) */}
      {uiStep === 'gallery' && (
        <div className="pt-10 pb-4 px-5 border-b border-white/5 bg-[#020617]/90 backdrop-blur-xl shrink-0 z-[100]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleBack}
                className="w-10 h-10 flex items-center justify-center text-white/70 hover:text-white text-xl active:scale-90 transition-transform cursor-pointer"
                title="Back"
              >
                <i className="fas fa-arrow-left"></i>
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => navigate('/')}
                    className="text-[10px] font-black text-white/40 uppercase tracking-widest cursor-pointer hover:text-white/80 transition-colors flex items-center"
                  >
                    Home <i className="fas fa-chevron-right mx-1 text-[7px]"></i>
                  </button>
                  {isRenamingFolder ? (
                    <input
                      autoFocus
                      defaultValue={folderName}
                      onBlur={(e) => {
                        setFolderName(e.target.value.trim() || 'Scan_Project_01');
                        setIsRenamingFolder(false);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          setFolderName(
                            (e.target as HTMLInputElement).value.trim() || 'Scan_Project_01'
                          );
                          setIsRenamingFolder(false);
                        }
                      }}
                      className="text-[10px] font-black text-teal-400 bg-teal-400/10 rounded px-2 py-0.5 outline-none border border-teal-400/30"
                    />
                  ) : (
                    <span
                      onClick={() => setIsRenamingFolder(true)}
                      className="text-[10px] font-black text-teal-400 uppercase tracking-widest cursor-pointer flex items-center gap-1.5 hover:text-teal-300"
                    >
                      {folderName} <i className="fas fa-pen text-[7px] opacity-40"></i>
                    </span>
                  )}
                </div>
                <h2 className="text-sm font-black text-white uppercase mt-1 tracking-tight">
                  {isSelectMode
                    ? `${selectedIds.size} Selected`
                    : `DOCUMENTS (${capturedPages.length})`}
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-2 relative">
              <button
                type="button"
                onClick={() => {
                  setIsSelectMode(!isSelectMode);
                  setSelectedIds(new Set());
                }}
                className={`w-10 h-10 flex items-center justify-center text-lg transition-all active:scale-90 ${
                  isSelectMode ? 'text-teal-400' : 'text-white/40'
                }`}
                title={isSelectMode ? 'Exit Select Mode' : 'Select Pages'}
              >
                <i className="fas fa-check-double"></i>
              </button>

              <button
                type="button"
                onClick={() => setShowTopMenu(!showTopMenu)}
                className={`w-10 h-10 flex items-center justify-center text-lg active:scale-90 transition-transform ${
                  showTopMenu ? 'text-teal-400' : 'text-white/40'
                }`}
                title="More Options"
              >
                <i className="fas fa-ellipsis-v"></i>
              </button>

              {showTopMenu && (
                <>
                  <div
                    className="fixed inset-0 z-[150]"
                    onClick={() => setShowTopMenu(false)}
                  />
                  <div className="absolute top-12 right-0 z-[160] w-56 bg-[#0f172a] border border-white/10 rounded-2xl p-2 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-150 flex flex-col gap-1 text-left">
                    <button
                      type="button"
                      onClick={() => {
                        setIsRenamingFolder(true);
                        setShowTopMenu(false);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 text-left text-xs font-bold text-white/80 hover:text-white"
                    >
                      <i className="fas fa-pen text-teal-400 w-4"></i>
                      <span>Rename Project</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsSelectMode(true);
                        setSelectedIds(new Set(capturedPages.map((p) => p.id)));
                        setShowTopMenu(false);
                      }}
                      disabled={capturedPages.length === 0}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 text-left text-xs font-bold text-white/80 hover:text-white disabled:opacity-30"
                    >
                      <i className="fas fa-check-double text-blue-400 w-4"></i>
                      <span>Select All Pages</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowTopMenu(false);
                        handleOpenExportStudio();
                      }}
                      disabled={capturedPages.length === 0}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 text-left text-xs font-bold text-white/80 hover:text-white disabled:opacity-30 cursor-pointer"
                    >
                      <i className="fas fa-file-export text-emerald-400 w-4"></i>
                      <span>Export &amp; Download Document</span>
                    </button>

                    <div className="h-px bg-white/5 my-1" />

                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm('Delete all scanned pages?')) {
                          setCapturedPages([]);
                          setSelectedIds(new Set());
                        }
                        setShowTopMenu(false);
                      }}
                      disabled={capturedPages.length === 0}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-rose-500/10 text-left text-xs font-bold text-rose-400 disabled:opacity-30"
                    >
                      <i className="fas fa-trash-can w-4"></i>
                      <span>Clear All Pages</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowTopMenu(false);
                        navigate('/');
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 text-left text-xs font-bold text-white/60 hover:text-white"
                    >
                      <i className="fas fa-house w-4"></i>
                      <span>Back to Home</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Hidden Multi-File Input for Images */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,application/pdf,.pdf"
        multiple
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* Hidden Multi-Document Input for PDF, DOCX, TXT, and Images */}
      <input
        ref={allFileInputRef}
        type="file"
        accept="image/*,application/pdf,.pdf,.doc,.docx,.txt"
        multiple
        className="hidden"
        onChange={handleAllFilesUpload}
      />

      {/* 2. MAIN GALLERY CONTENT */}
      {uiStep === 'gallery' && (
        <div className="flex-1 overflow-y-auto p-5 no-scrollbar pb-36 bg-[#020617]">
          {!isSelectMode && capturedPages.length > 1 && (
            <p className="text-[9px] font-black text-white/30 uppercase tracking-widest mb-3">
              Tap a page to edit &bull; Hold to multi-select &bull; Drag to reorder
            </p>
          )}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
            {!isSelectMode && (
              <div
                id="scan-page-card"
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  startCamera();
                }}
                className="aspect-[3/4] rounded-2xl border-2 border-dashed border-teal-500/40 bg-teal-500/5 flex flex-col items-center justify-center text-teal-400 active:scale-95 transition-all cursor-pointer hover:bg-teal-500/10 hover:border-teal-400"
              >
                <div className="w-12 h-12 rounded-xl bg-teal-500/15 flex items-center justify-center mb-3 text-xl text-teal-400">
                  <i className="fas fa-camera"></i>
                </div>
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-center px-2">
                  Scan Page
                </span>
                <span className="text-[7px] text-teal-400/60 mt-0.5">Camera / Scanner</span>
              </div>
            )}

            {!isSelectMode && (
              <div
                id="upload-images-card"
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="aspect-[3/4] rounded-2xl border-2 border-dashed border-white/10 bg-white/5 flex flex-col items-center justify-center text-white/40 active:scale-95 transition-all cursor-pointer hover:bg-white/10 hover:border-white/20"
              >
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-3 text-xl text-white/60">
                  <i className="fas fa-images"></i>
                </div>
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-center px-2">
                  Upload Images
                </span>
                <span className="text-[7px] text-white/30 mt-0.5">From Gallery</span>
              </div>
            )}

            {/* FULL-WIDTH ROUNDED BUTTON ROW DIRECTLY BELOW CARDS */}
            {!isSelectMode && (
              <div className="col-span-2 sm:col-span-3 md:col-span-4 flex items-center gap-3 w-full my-1">
                {/* 1. ADD FILE / UPLOAD FILE button */}
                <button
                  type="button"
                  id="btn-add-file"
                  onClick={() => allFileInputRef.current?.click()}
                  className="flex-1 flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-2xl bg-[#0f172a] hover:bg-[#1e293b] active:scale-[0.98] transition-all border border-teal-500/30 text-teal-300 shadow-lg group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-teal-500/15 flex items-center justify-center text-teal-400 group-hover:bg-teal-500/25 transition-colors">
                    <i className="fas fa-paperclip text-sm"></i>
                  </div>
                  <div className="text-left">
                    <span className="block text-[11px] font-black uppercase tracking-[0.16em] text-white">
                      ADD FILE
                    </span>
                    <span className="block text-[8px] font-bold text-teal-400/80 uppercase tracking-wider">
                      PDF, DOCX, TXT, IMG
                    </span>
                  </div>
                </button>

                {/* 2. DOWNLOAD SCAN button: Opens Export Studio first without auto-downloading */}
                <button
                  type="button"
                  id="btn-download-scan"
                  onClick={handleOpenExportStudio}
                  disabled={capturedPages.length === 0}
                  title={capturedPages.length > 0 ? 'Export & Download Document' : 'No documents to download'}
                  className={`flex-1 flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-2xl transition-all border active:scale-[0.98] ${
                    capturedPages.length > 0
                      ? 'bg-teal-500 hover:bg-teal-400 text-slate-950 border-teal-400 shadow-[0_0_20px_rgba(20,184,166,0.35)] cursor-pointer'
                      : 'bg-white/5 text-white/30 border-white/5 cursor-not-allowed opacity-50'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm ${
                      capturedPages.length > 0
                        ? 'bg-slate-950/20 text-slate-950'
                        : 'bg-white/5 text-white/20'
                    }`}
                  >
                    <i className="fas fa-download"></i>
                  </div>
                  <div className="text-left">
                    <span
                      className={`block text-[11px] font-black uppercase tracking-[0.16em] ${
                        capturedPages.length > 0 ? 'text-slate-950' : 'text-white/40'
                      }`}
                    >
                      DOWNLOAD SCAN
                    </span>
                    <span
                      className={`block text-[8px] font-bold uppercase tracking-wider ${
                        capturedPages.length > 0 ? 'text-slate-950/70' : 'text-white/20'
                      }`}
                    >
                      {capturedPages.length > 0
                        ? `Export Single PDF (${capturedPages.length})`
                        : '0 Documents'}
                    </span>
                  </div>
                </button>
              </div>
            )}

            {/* EMPTY STATE (When project has 0 documents) */}
            {capturedPages.length === 0 && !isSelectMode && (
              <div className="col-span-2 sm:col-span-3 md:col-span-4 rounded-2xl border border-dashed border-white/10 bg-white/[0.02] p-8 flex flex-col items-center justify-center text-center my-2">
                <div className="w-14 h-14 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400 text-2xl mb-3">
                  <i className="fas fa-file-circle-plus"></i>
                </div>
                <h3 className="text-xs font-black uppercase tracking-widest text-white/90 mb-1">
                  No Documents In This Project
                </h3>
                <p className="text-[10px] text-white/40 max-w-xs leading-relaxed">
                  Use <span className="text-teal-400 font-bold">Scan Page</span>, <span className="text-teal-400 font-bold">Upload Images</span>, or <span className="text-teal-400 font-bold">Add File</span> to import documents into this project.
                </p>
              </div>
            )}

            {/* DOCUMENT LIST STATE */}
            {capturedPages.map((p, index) => (
              <div
                key={p.id}
                className="flex flex-col animate-in zoom-in duration-200"
                draggable={!isSelectMode}
                onDragStart={() => handleDragStart(index)}
                onDragOver={handleDragOver}
                onDrop={() => handleDrop(index)}
              >
                <div
                  onMouseDown={() => handleTouchStart(p.id)}
                  onMouseUp={handleTouchEnd}
                  onTouchStart={() => handleTouchStart(p.id)}
                  onTouchEnd={handleTouchEnd}
                  onClick={() =>
                    isSelectMode
                      ? toggleSelect(p.id)
                      : (setPreviewPage(p), setUiStep('preview'))
                  }
                  className={`relative aspect-[3/4] bg-white/5 rounded-2xl overflow-hidden shadow-2xl border-2 transition-all cursor-pointer ${
                    selectedIds.has(p.id)
                      ? 'border-teal-500 ring-4 ring-teal-500/20'
                      : 'border-white/5'
                  }`}
                >
                  <img
                    src={p.processed}
                    className="w-full h-full object-cover"
                    alt={p.name}
                  />

                  {selectedIds.has(p.id) && (
                    <div className="absolute inset-0 bg-teal-500/20 flex items-center justify-center animate-in fade-in duration-150">
                      <div className="w-11 h-11 bg-teal-500 rounded-full flex items-center justify-center text-white text-base shadow-xl border-2 border-white">
                        <i className="fas fa-check"></i>
                      </div>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedMenuPage(p);
                    }}
                    className="absolute top-2 right-2 w-7 h-7 bg-black/50 hover:bg-teal-500 hover:text-black backdrop-blur-md rounded-full flex items-center justify-center text-white text-[10px] shadow-md transition-all active:scale-90 z-10 cursor-pointer"
                    title="Page Options"
                  >
                    <i className="fas fa-ellipsis-h"></i>
                  </button>

                  <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-md text-white text-[9px] font-black px-2 py-0.5 rounded-md">
                    #{index + 1}
                  </div>
                </div>

                <div className="pt-2 px-1">
                  {editingPageId === p.id ? (
                    <div
                      className="flex items-center gap-1 w-full"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        autoFocus
                        type="text"
                        value={editingPageName}
                        onChange={(e) => setEditingPageName(e.target.value)}
                        onBlur={() => {
                          handleRenamePage(p.id, editingPageName);
                          setEditingPageId(null);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleRenamePage(p.id, editingPageName);
                            setEditingPageId(null);
                          } else if (e.key === 'Escape') {
                            setEditingPageId(null);
                          }
                        }}
                        className="w-full text-[10px] font-black text-teal-300 bg-teal-950/80 border border-teal-400/50 rounded px-1.5 py-0.5 outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          handleRenamePage(p.id, editingPageName);
                          setEditingPageId(null);
                        }}
                        className="text-teal-400 text-xs px-1 hover:text-teal-200"
                      >
                        <i className="fas fa-check"></i>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between mb-0.5 w-full">
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingPageId(p.id);
                          setEditingPageName(p.name);
                        }}
                        className="flex items-center gap-1 cursor-pointer group/name truncate flex-1 mr-1"
                      >
                        <span className="text-[10px] font-black text-white/90 uppercase truncate group-hover/name:text-teal-300 transition-colors">
                          {p.name}
                        </span>
                        <i className="fas fa-pencil text-[7px] text-teal-400/40 group-hover/name:text-teal-400"></i>
                      </div>
                      <span className="text-[8px] font-bold text-white/25 uppercase">
                        {p.date}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. FLOATING CAMERA, ADD FILES & DOWNLOAD BUTTONS (Positioned safely above 60px Ad Banner) */}
      {uiStep === 'gallery' && !isSelectMode && (
        <div className="fixed bottom-20 right-6 flex flex-col items-end gap-3 z-[200]">
          {/* Small grey download FAB: opens Export Studio first without auto-downloading */}
          <button
            type="button"
            id="documents-download-fab"
            onClick={handleOpenExportStudio}
            disabled={capturedPages.length === 0}
            title={capturedPages.length > 0 ? 'Export & Download Document' : 'No documents to download'}
            className={`w-12 h-12 rounded-full flex items-center justify-center text-base shadow-xl transition-all active:scale-90 ${
              capturedPages.length > 0
                ? 'bg-slate-800 text-white hover:bg-slate-700 border border-white/15 cursor-pointer shadow-black/50'
                : 'bg-slate-900/60 text-white/20 cursor-not-allowed border border-white/5'
            }`}
          >
            <i className="fas fa-download"></i>
          </button>

          {/* Bottom Action Row: Side-by-side Add Files FAB and Camera FAB */}
          <div className="flex items-center gap-3">
            {/* Vibrant Cyan Floating Add Files / Upload Images Button */}
            <button
              type="button"
              id="documents-upload-fab"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                allFileInputRef.current?.click();
              }}
              title="Add Files or Upload Images / PDF Documents"
              aria-label="Add files or upload images"
              className="w-16 h-16 bg-gradient-to-tr from-cyan-500 to-sky-400 rounded-2xl flex items-center justify-center text-slate-950 shadow-[0_15px_40px_-10px_rgba(6,182,212,0.6)] active:scale-90 transition-all border-2 border-white/25 hover:brightness-110 cursor-pointer relative group"
            >
              <div className="relative flex items-center justify-center">
                <i className="fas fa-image text-2xl group-hover:scale-105 transition-transform"></i>
                <span className="absolute -bottom-1.5 -right-2 w-5 h-5 bg-slate-950 text-cyan-300 rounded-full flex items-center justify-center text-[10px] font-black border border-cyan-400 shadow-sm">
                  <i className="fas fa-plus"></i>
                </span>
              </div>
            </button>

            {/* Teal Camera FAB Button: strictly triggers camera / native document scanner */}
            <button
              type="button"
              id="documents-camera-fab"
              onClick={handleCameraFabClick}
              title="Scan Document Page"
              aria-label="Scan document page"
              className="w-16 h-16 bg-teal-500 rounded-2xl flex items-center justify-center text-slate-950 text-2xl shadow-[0_15px_40px_-10px_rgba(20,184,166,0.6)] active:scale-90 transition-all border-2 border-white/20 hover:brightness-110 cursor-pointer"
            >
              <i className="fas fa-camera"></i>
            </button>
          </div>
        </div>
      )}

      {/* 4. MULTI-SELECT FOOTER */}
      {uiStep === 'gallery' && isSelectMode && (
        <div className="bg-[#0f172a] p-4 px-6 border-t border-white/10 flex gap-3 shadow-2xl z-[300] shrink-0">
          <button
            type="button"
            onClick={() => {
              setCapturedPages((prev) => prev.filter((p) => !selectedIds.has(p.id)));
              setSelectedIds(new Set());
              setIsSelectMode(false);
            }}
            disabled={selectedIds.size === 0}
            className="flex-1 bg-rose-500/15 text-rose-400 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest disabled:opacity-20 active:scale-95 transition-all border border-rose-500/30 flex items-center justify-center gap-2"
          >
            <i className="fas fa-trash-alt"></i> Delete ({selectedIds.size})
          </button>
          <button
            type="button"
            onClick={handleOpenExportStudio}
            disabled={selectedIds.size === 0}
            className="flex-1 bg-teal-500 text-slate-950 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest disabled:opacity-20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fas fa-file-export"></i> Export ({selectedIds.size})
          </button>
          <button
            type="button"
            onClick={() => {
              setIsSelectMode(false);
              setSelectedIds(new Set());
            }}
            className="px-5 bg-white/5 text-white/60 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest active:scale-95 transition-all"
          >
            Cancel
          </button>
        </div>
      )}

      {/* 5. FULLSCREEN CAMERA INTERFACE */}
      {uiStep === 'camera' && (
        <div className="absolute inset-0 z-[500] flex flex-col bg-black animate-in fade-in duration-200 overflow-hidden">
          {shutterFlash && (
            <div className="absolute inset-0 bg-white z-[600] pointer-events-none transition-opacity duration-150 animate-out fade-out" />
          )}

          {captureNotice && (
            <div className="absolute top-24 left-1/2 -translate-x-1/2 z-[550] bg-emerald-400 text-slate-950 px-4 py-2 rounded-2xl font-black text-xs uppercase tracking-wider shadow-2xl flex items-center gap-2 animate-in fade-in zoom-in-95 duration-150 border border-white/30">
              <i className="fas fa-check-circle text-sm"></i>
              <span>{captureNotice}</span>
            </div>
          )}

          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 w-full h-full object-cover"
            onLoadedMetadata={() => videoRef.current?.play().catch(() => {})}
          />

          <div className="absolute top-10 left-0 right-0 px-6 flex justify-between items-center z-[510]">
            <button
              type="button"
              onClick={stopCamera}
              className="w-11 h-11 bg-black/50 backdrop-blur-md rounded-full text-white active:scale-90 transition-transform flex items-center justify-center border border-white/15"
            >
              <i className="fas fa-times text-lg"></i>
            </button>
            <div className="bg-black/50 backdrop-blur-md p-1 rounded-2xl border border-white/15 flex">
              <button
                type="button"
                onClick={() => setIsAutoMode(true)}
                className={`px-5 py-1.5 rounded-xl text-[10px] font-black uppercase transition-all ${
                  isAutoMode
                    ? 'bg-teal-500 text-black shadow-lg shadow-teal-500/30'
                    : 'text-white/60'
                }`}
              >
                Auto Crop
              </button>
              <button
                type="button"
                onClick={() => setIsAutoMode(false)}
                className={`px-5 py-1.5 rounded-xl text-[10px] font-black uppercase transition-all ${
                  !isAutoMode
                    ? 'bg-teal-500 text-black shadow-lg shadow-teal-500/30'
                    : 'text-white/60'
                }`}
              >
                Manual
              </button>
            </div>
            <button
              type="button"
              onClick={() => setIsFlashOn(!isFlashOn)}
              className={`w-11 h-11 rounded-full backdrop-blur-md transition-all active:scale-90 flex items-center justify-center border border-white/15 ${
                isFlashOn
                  ? 'bg-amber-500 text-slate-950 border-amber-400'
                  : 'bg-black/50 text-white'
              }`}
            >
              <i className={`fas ${isFlashOn ? 'fa-bolt' : 'fa-bolt-slash'}`}></i>
            </button>
          </div>

          {isAutoMode && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-[82%] aspect-[3/4] border-2 border-teal-500/40 rounded-3xl relative">
                <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-teal-400 rounded-tl-xl" />
                <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-teal-400 rounded-tr-xl" />
                <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-teal-400 rounded-bl-xl" />
                <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-teal-400 rounded-br-xl" />
              </div>
            </div>
          )}

          <div className="absolute bottom-0 left-0 right-0 p-8 pb-12 flex items-center justify-between px-12 bg-gradient-to-t from-black/90 via-black/50 to-transparent z-[510]">
            <button
              type="button"
              onClick={stopCamera}
              className="w-14 h-14 rounded-2xl border-2 border-white/20 overflow-hidden bg-black/50 backdrop-blur-md cursor-pointer flex items-center justify-center active:scale-95"
            >
              {capturedPages.length > 0 ? (
                <img
                  src={capturedPages[capturedPages.length - 1].processed}
                  className="w-full h-full object-cover"
                  alt="Last scan"
                />
              ) : (
                <i className="fas fa-images text-white/30"></i>
              )}
            </button>

            <button
              type="button"
              onClick={capturePhoto}
              className="w-20 h-20 rounded-full border-[6px] border-white/30 p-1.5 active:scale-90 transition-all shadow-2xl group relative"
            >
              <div className="w-full h-full bg-white rounded-full group-hover:scale-95 transition-transform" />
            </button>

            <button
              type="button"
              onClick={stopCamera}
              className="w-14 h-14 flex flex-col items-center justify-center text-white bg-teal-500/20 backdrop-blur-md rounded-2xl border border-teal-400/40 active:scale-95 transition-all"
            >
              <span className="text-lg font-black text-teal-300">
                {capturedPages.length}
              </span>
              <span className="text-[8px] font-black uppercase tracking-widest text-teal-200/70">
                Done
              </span>
            </button>
          </div>
        </div>
      )}

      {/* 6. IMAGE PREVIEW & EDITOR STEP */}
      {uiStep === 'preview' && previewPage && (
        <div className="flex-1 flex flex-col bg-[#020617] overflow-hidden z-[400]">
          <div className="pt-10 pb-3 px-5 border-b border-white/5 flex items-center justify-between bg-[#0f172a] shrink-0">
            <button
              type="button"
              onClick={() => {
                setIsCropping(false);
                setUiStep('gallery');
              }}
              className="w-10 h-10 flex items-center justify-center text-white/70 text-lg active:scale-90 transition-transform"
            >
              <i className="fas fa-arrow-left"></i>
            </button>

            <button
              type="button"
              onClick={() => {
                setRenameModalPage(previewPage);
                setRenameInputVal(previewPage.name);
              }}
              className="text-xs font-black uppercase tracking-widest text-teal-400 flex items-center gap-1.5 hover:text-teal-300"
            >
              <span className="truncate max-w-[160px]">{previewPage.name}</span>
              <i className="fas fa-pencil text-[8px] opacity-60"></i>
            </button>

            <button
              type="button"
              onClick={async () => {
                if (isCropping) {
                  await applyFilterAndCrop(previewPage.id, previewPage.filter, true);
                }
                setUiStep('gallery');
              }}
              className="bg-teal-500 text-slate-950 px-5 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg shadow-teal-500/20 active:scale-95 transition-all"
            >
              {isCropping ? 'Apply Crop' : 'Done'}
            </button>
          </div>

          <div className="flex-1 relative bg-black overflow-hidden flex items-center justify-center p-2">
            {isCropping ? (
              <div className="absolute inset-0">
                <Cropper
                  image={previewPage.original}
                  crop={crop}
                  zoom={zoom}
                  aspect={undefined}
                  onCropChange={setCrop}
                  onCropComplete={onCropComplete}
                  onZoomChange={setZoom}
                />
              </div>
            ) : (
              <img
                src={previewPage.processed}
                className="max-w-full max-h-full object-contain shadow-2xl"
                alt={previewPage.name}
              />
            )}
          </div>

          <div className="bg-[#0f172a] p-4 border-t border-white/5 flex flex-col gap-4 shrink-0">
            {/* Filter Selector Bar */}
            {!isCropping && (
              <div className="flex items-center justify-center sm:justify-start gap-3 overflow-x-auto no-scrollbar pb-1">
                {[
                  { id: 'none', label: 'Original', icon: 'fa-image' },
                  { id: 'magic_color', label: 'Magic', icon: 'fa-wand-magic-sparkles' },
                  { id: 'document', label: 'Doc', icon: 'fa-file-lines' },
                  { id: 'bw', label: 'B&W', icon: 'fa-circle-half-stroke' },
                  { id: 'grayscale', label: 'Gray', icon: 'fa-palette' },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() =>
                      applyFilterAndCrop(previewPage.id, f.id as ScanFilter, false)
                    }
                    className={`flex flex-col items-center gap-1.5 min-w-[60px] transition-all active:scale-90 ${
                      previewPage.filter === f.id ? 'text-teal-400' : 'text-white/40'
                    }`}
                  >
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center text-base border-2 transition-all ${
                        previewPage.filter === f.id
                          ? 'bg-teal-400/15 border-teal-400'
                          : 'bg-white/5 border-transparent'
                      }`}
                    >
                      <i className={`fas ${f.icon}`}></i>
                    </div>
                    <span className="text-[8px] font-black uppercase tracking-widest">
                      {f.label}
                    </span>
                  </button>
                ))}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => {
                  if (isCropping) {
                    applyFilterAndCrop(previewPage.id, previewPage.filter, true);
                  } else {
                    setIsCropping(true);
                  }
                }}
                className={`flex-1 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  isCropping
                    ? 'bg-teal-500 text-slate-950'
                    : 'bg-white/5 text-white/80 border border-white/10'
                }`}
              >
                <i className={`fas ${isCropping ? 'fa-check' : 'fa-crop-simple'}`}></i>
                <span>{isCropping ? 'Save Crop' : 'Crop'}</span>
              </button>

              {isCropping ? (
                <button
                  type="button"
                  onClick={() => setIsCropping(false)}
                  className="flex-1 py-3.5 bg-white/5 text-white/70 border border-white/10 rounded-2xl font-black text-[10px] uppercase tracking-widest"
                >
                  Cancel Crop
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => handleRotatePage(previewPage.id)}
                    className="flex-1 py-3.5 bg-white/5 hover:bg-white/10 text-white/80 border border-white/10 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-1.5 active:scale-95"
                  >
                    <i className="fas fa-rotate-right"></i> Rotate
                  </button>

                  <button
                    type="button"
                    onClick={() => handleResetPageToRaw(previewPage.id)}
                    className="py-3.5 px-4 bg-white/5 hover:bg-white/10 text-white/60 border border-white/10 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95"
                    title="Reset to Original"
                  >
                    <i className="fas fa-rotate-left"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const delId = previewPage.id;
                      setCapturedPages((prev) =>
                        prev.filter((p) => p.id !== delId)
                      );
                      setPreviewPage(null);
                      setUiStep('gallery');
                    }}
                    className="py-3.5 px-4 bg-rose-500/15 text-rose-400 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-rose-500/25 active:scale-95"
                    title="Delete Page"
                  >
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 7. EXPORT / SHARE MODAL */}
      {showShareModal && (
        <div className="fixed inset-0 z-[1000] bg-black/80 backdrop-blur-xl animate-in fade-in flex items-end justify-center">
          <div className="w-full bg-white text-slate-900 rounded-t-[2.5rem] p-6 pb-20 max-w-xl mx-auto shadow-2xl flex flex-col gap-5">
            <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
              <div className="w-14 h-14 bg-blue-600 text-white rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-blue-600/20 shrink-0">
                <i className="fas fa-file-export"></i>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-black truncate">{folderName}</h3>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-0.5">
                  {isSelectMode ? selectedIds.size : capturedPages.length} Page(s) Ready
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between py-1">
                <span className="text-xs font-bold text-slate-700">Output Format</span>
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setExportFormat('PDF')}
                    className={`px-5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                      exportFormat === 'PDF'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-slate-400'
                    }`}
                  >
                    PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => setExportFormat('JPG')}
                    className={`px-5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                      exportFormat === 'JPG'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-slate-400'
                    }`}
                  >
                    JPG
                  </button>
                </div>
              </div>

              {[
                {
                  label: 'Save Pages Separately (.ZIP)',
                  value: saveSeparately,
                  setter: setSaveSeparately,
                },
                {
                  label: 'Enable PDF Password',
                  value: enablePassword,
                  setter: setEnablePassword,
                  disabled: exportFormat === 'JPG',
                },
                {
                  label: 'Extract OCR Text (.TXT) with Google AI (Free)',
                  value: enableOCR,
                  setter: setEnableOCR,
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className={`flex items-center justify-between py-2.5 border-b border-slate-100 ${
                    item.disabled ? 'opacity-40' : ''
                  }`}
                >
                  <span className="text-xs font-bold text-slate-700">{item.label}</span>
                  <button
                    type="button"
                    disabled={item.disabled}
                    onClick={() => item.setter(!item.value)}
                    className={`w-11 h-6 rounded-full transition-all relative ${
                      item.value ? 'bg-blue-600' : 'bg-slate-200'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all shadow-sm ${
                        item.value ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>
              ))}

              {/* Inline Password Input (Replaces blocked window.prompt) */}
              {enablePassword && exportFormat === 'PDF' && (
                <div className="pt-1">
                  <input
                    type="password"
                    value={pdfPassword}
                    onChange={(e) => setPdfPassword(e.target.value)}
                    placeholder="Enter PDF password..."
                    className="w-full px-3.5 py-2.5 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-slate-800"
                  />
                </div>
              )}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="flex-1 py-4 bg-slate-100 rounded-2xl font-black text-slate-500 uppercase tracking-widest text-xs active:scale-95 transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExport}
                className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-600/25 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <i className="fas fa-download"></i> Export Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7b. PAGE ACTIONS MODAL */}
      {selectedMenuPage && (
        <div className="fixed inset-0 z-[1100] bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0f172a] text-white border-t sm:border border-white/10 rounded-t-[2.5rem] sm:rounded-3xl p-6 pb-20 sm:pb-6 shadow-2xl flex flex-col gap-3">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <img
                src={selectedMenuPage.processed}
                alt={selectedMenuPage.name}
                className="w-12 h-16 object-cover rounded-xl border border-white/10 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-black text-white uppercase truncate">
                  {selectedMenuPage.name}
                </h3>
                <p className="text-[10px] text-white/40">{selectedMenuPage.date}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedMenuPage(null)}
                className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white/60 text-sm"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            {/* Mobile Reorder Controls */}
            {capturedPages.length > 1 && (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleMovePage(selectedMenuPage.id, 'left')}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold flex items-center justify-center gap-1.5"
                >
                  <i className="fas fa-arrow-left text-teal-400"></i> Move Earlier
                </button>
                <button
                  type="button"
                  onClick={() => handleMovePage(selectedMenuPage.id, 'right')}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold flex items-center justify-center gap-1.5"
                >
                  Move Later <i className="fas fa-arrow-right text-teal-400"></i>
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 gap-1.5">
              <button
                type="button"
                onClick={() => {
                  const page = selectedMenuPage;
                  setSelectedMenuPage(null);
                  setRenameModalPage(page);
                  setRenameInputVal(page.name);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs"
              >
                <i className="fas fa-pencil text-teal-400 w-5"></i>
                <span>Rename Page</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPreviewPage(selectedMenuPage);
                  setUiStep('preview');
                  setSelectedMenuPage(null);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs"
              >
                <i className="fas fa-crop-simple text-blue-400 w-5"></i>
                <span>Edit, Crop &amp; Filters</span>
              </button>

              <button
                type="button"
                onClick={() => handleRotatePage(selectedMenuPage.id)}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs"
              >
                <i className="fas fa-rotate-right text-emerald-400 w-5"></i>
                <span>Rotate 90° Clockwise</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleExportSinglePage(selectedMenuPage, 'PDF');
                  setSelectedMenuPage(null);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs"
              >
                <i className="fas fa-file-pdf text-amber-400 w-5"></i>
                <span>Download Page as PDF</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleExportSinglePage(selectedMenuPage, 'JPG');
                  setSelectedMenuPage(null);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs"
              >
                <i className="fas fa-file-image text-cyan-400 w-5"></i>
                <span>Download Page as JPG</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const pageId = selectedMenuPage.id;
                  setCapturedPages((prev) => prev.filter((p) => p.id !== pageId));
                  if (previewPage?.id === pageId) {
                    setPreviewPage(null);
                  }
                  setSelectedMenuPage(null);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold text-xs border border-rose-500/20"
              >
                <i className="fas fa-trash-can w-5"></i>
                <span>Delete Page</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7c. DEDICATED RENAME MODAL */}
      {renameModalPage && (
        <div className="fixed inset-0 z-[1200] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0f172a] text-white border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black uppercase tracking-tight flex items-center gap-2">
                <i className="fas fa-pencil text-teal-400"></i> Rename Page
              </h3>
              <button
                type="button"
                onClick={() => setRenameModalPage(null)}
                className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white/60 text-sm"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <input
              autoFocus
              type="text"
              value={renameInputVal}
              onChange={(e) => setRenameInputVal(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleRenamePage(renameModalPage.id, renameInputVal);
                  setRenameModalPage(null);
                } else if (e.key === 'Escape') {
                  setRenameModalPage(null);
                }
              }}
              placeholder="e.g. ID Front, Bill Page 1..."
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-sm font-bold text-white focus:outline-none focus:border-teal-400"
            />

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setRenameModalPage(null)}
                className="flex-1 py-3 rounded-xl bg-white/5 text-white/60 font-black text-xs uppercase"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleRenamePage(renameModalPage.id, renameInputVal);
                  setRenameModalPage(null);
                }}
                className="flex-1 py-3 rounded-xl bg-teal-500 text-slate-950 font-black text-xs uppercase"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. LOADING / PROCESSING OVERLAY */}
      {(state.status === 'processing' || state.status === 'loading') && (
        <div className="fixed inset-0 z-[2000] bg-black/95 backdrop-blur-3xl flex flex-col items-center justify-center p-12 text-center text-white">
          <div className="relative w-28 h-28 mb-8">
            <div className="absolute inset-0 border-[6px] border-white/10 rounded-full" />
            <div className="absolute inset-0 border-[6px] border-teal-500 border-t-transparent rounded-full animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center text-teal-400 text-xl font-black">
              {state.progress}%
            </div>
          </div>
          <h2 className="text-2xl font-black mb-2 uppercase tracking-tight">Working...</h2>
          <p className="text-white/40 font-black uppercase text-[10px] tracking-[0.3em] max-w-xs">
            {state.message}
          </p>

          {/* User Cancel / Dismiss Escape Hatch */}
          <button
            type="button"
            onClick={() => {
              setState({ status: 'idle', progress: 0 });
              setUiStep('gallery');
            }}
            className="mt-8 px-6 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-black text-xs uppercase tracking-widest border border-white/15 transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
          >
            <i className="fas fa-times text-xs"></i>
            <span>Cancel &amp; Continue</span>
          </button>
        </div>
      )}

      {/* 8b. ERROR OVERLAY */}
      {state.status === 'error' && (
        <div className="fixed inset-0 z-[2500] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-8 text-center text-white">
          <div className="w-20 h-20 rounded-3xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center text-3xl mb-6">
            <i className="fas fa-triangle-exclamation"></i>
          </div>
          <h3 className="text-xl font-black uppercase mb-2">Something Went Wrong</h3>
          <p className="text-xs text-white/60 max-w-xs mb-6">{state.message}</p>
          <button
            type="button"
            onClick={() => setState({ status: 'idle', progress: 0 })}
            className="px-8 py-3.5 rounded-2xl bg-teal-500 text-slate-950 font-black text-xs uppercase tracking-widest"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* 9. ADVANCED EXPORT, COMPRESSION & SHARE STUDIO */}
      {state.status === 'success' && (
        <div className="fixed inset-0 z-[3000] bg-[#020617] text-white flex flex-col justify-between items-center animate-in zoom-in-95 duration-200 overflow-y-auto no-scrollbar">
          {/* Top Sticky Header */}
          <div className="w-full sticky top-0 z-20 bg-[#020617]/90 backdrop-blur-xl border-b border-slate-800/80 px-4 py-3 flex items-center justify-between max-w-lg mx-auto">
            <button
              type="button"
              onClick={() => {
                setState({ status: 'idle', progress: 0 });
                setHasDownloaded(false);
                setUiStep('gallery');
              }}
              className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-wider text-slate-400 hover:text-white transition-colors py-1 px-2 rounded-xl hover:bg-slate-800/60"
            >
              <i className="fas fa-arrow-left text-xs"></i>
              <span>Folder</span>
            </button>
            <div className="text-center">
              <span className="text-xs font-black uppercase tracking-widest text-slate-200">
                Export &amp; Share
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[11px] font-bold text-teal-400 bg-teal-950/60 border border-teal-500/30 px-2.5 py-1 rounded-xl">
              <i className="fas fa-folder-closed text-[10px]"></i>
              <span className="truncate max-w-[90px]">{folderName}</span>
            </div>
          </div>

          {/* Main Studio Body */}
          <div className="flex-1 w-full max-w-md mx-auto p-4 sm:p-5 space-y-4 my-auto">
            {/* Top Hero Status Banner */}
            <div className="flex flex-col items-center text-center pt-1">
              <div className="w-20 h-20 bg-gradient-to-tr from-teal-500 to-emerald-400 text-slate-950 text-3xl rounded-3xl flex items-center justify-center mb-3 shadow-xl shadow-teal-500/20 border-2 border-white/20 shrink-0">
                <i className={`fas ${hasDownloaded ? 'fa-check-double' : 'fa-file-export'}`}></i>
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight uppercase">
                {hasDownloaded ? 'DONE!' : 'EXPORT DOCUMENT'}
              </h2>
              <p className="text-slate-400 font-mono text-xs font-bold truncate max-w-full px-4 mt-0.5">
                {state.resultFileName || `${folderName}.${exportFormatSelection.toLowerCase()}`}
              </p>
              <div className="flex items-center gap-2 mt-1.5 flex-wrap justify-center">
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {targetPages.length} {targetPages.length === 1 ? 'Page' : 'Pages'}
                </span>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 border border-emerald-500/30">
                  Est. ~{currentEstimate.formatted}
                </span>
              </div>
            </div>

            {/* 4. SAVED LOCATION / FOLDER PATH CONFIRMATION CARD (CRITICAL) */}
            {savedFeedback && savedFeedback.visible && (
              <div className="w-full bg-gradient-to-br from-emerald-950/90 via-slate-900/95 to-emerald-950/80 border-2 border-emerald-500/60 rounded-3xl p-4 sm:p-5 shadow-2xl shadow-emerald-950/60 backdrop-blur-xl animate-in slide-in-from-top-3 duration-300 relative text-left">
                {/* Dismiss button */}
                <button
                  type="button"
                  onClick={() => setSavedFeedback((prev) => (prev ? { ...prev, visible: false } : null))}
                  className="absolute top-3.5 right-3.5 w-7 h-7 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs transition-colors"
                  title="Dismiss banner"
                >
                  <i className="fas fa-times"></i>
                </button>

                {/* Status Header */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center text-lg font-black shadow-lg shadow-emerald-500/30 shrink-0">
                    <i className="fas fa-check"></i>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-emerald-400 tracking-wide uppercase">
                        File Saved Successfully!
                      </span>
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30 uppercase">
                        SAVED
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 font-medium">
                      {savedFeedback.fileSizeText ? `${savedFeedback.fileSizeText} · ` : ''}File ready in storage
                    </p>
                  </div>
                </div>

                {/* File Details Box */}
                <div className="bg-slate-950/80 border border-emerald-500/25 rounded-2xl p-3 space-y-2 mb-3.5">
                  <div>
                    <div className="text-[10px] text-slate-400 font-sans font-bold uppercase tracking-wider mb-0.5 flex items-center gap-1.5">
                      <i className="fas fa-file-lines text-emerald-400"></i>
                      <span>File Name</span>
                    </div>
                    <div className="text-xs font-bold text-slate-100 break-all select-all font-mono">
                      {savedFeedback.fileName}
                    </div>
                  </div>

                  <div className="pt-1.5 border-t border-slate-800/80">
                    <div className="text-[10px] text-slate-400 font-sans font-bold uppercase tracking-wider mb-0.5 flex items-center gap-1.5">
                      <i className="fas fa-folder-open text-amber-400"></i>
                      <span>Folder Location</span>
                    </div>
                    <div className="text-xs font-bold text-emerald-300 break-all select-all flex items-center gap-1.5 font-mono">
                      <span>{savedFeedback.savedPath}</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons inside the banner */}
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() =>
                      openSavedFileSafely(
                        savedFeedback.savedPath,
                        savedFeedback.mimeType,
                        savedFeedback.blobUrl || state.resultUrl
                      )
                    }
                    className="w-full bg-emerald-600 hover:bg-emerald-500 active:scale-95 transition-all text-white font-black py-2.5 px-3 rounded-2xl flex items-center justify-center gap-2 text-xs uppercase tracking-wider shadow-lg shadow-emerald-900/40 cursor-pointer"
                  >
                    <i className="fas fa-folder-open text-sm"></i>
                    <span>Open File</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      shareSavedFileSafely(
                        savedFeedback.savedPath,
                        savedFeedback.mimeType,
                        currentResultBlob || savedFeedback.blob || state.resultUrl,
                        savedFeedback.fileName
                      )
                    }
                    className="w-full bg-slate-800/90 hover:bg-slate-700 active:scale-95 transition-all text-emerald-300 font-black py-2.5 px-3 rounded-2xl border border-emerald-500/40 flex items-center justify-center gap-2 text-xs uppercase tracking-wider shadow-md cursor-pointer"
                  >
                    <i className="fas fa-share-nodes text-sm"></i>
                    <span>Share Now</span>
                  </button>
                </div>
              </div>
            )}

            {/* 1. FORMAT & PAGE MODE SELECTION CARD */}
            <div className="w-full bg-slate-900/80 border border-slate-800/90 rounded-3xl p-4 sm:p-5 text-left space-y-3.5 backdrop-blur-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center text-xs font-black">
                    1
                  </span>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-200">
                    File Format &amp; Mode
                  </h3>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  {targetPages.length} {targetPages.length === 1 ? 'Page' : 'Pages'}
                </span>
              </div>

              {/* Format Selector Pills */}
              <div className="grid grid-cols-4 gap-2">
                {(['PDF', 'JPG', 'PNG', 'ZIP'] as ExportFileFormat[]).map((fmt) => {
                  const isSelected = exportFormatSelection === fmt;
                  const icon =
                    fmt === 'PDF'
                      ? 'fa-file-pdf'
                      : fmt === 'JPG'
                      ? 'fa-file-image'
                      : fmt === 'PNG'
                      ? 'fa-image'
                      : 'fa-file-zipper';
                  return (
                    <button
                      key={fmt}
                      type="button"
                      onClick={() => setExportFormatSelection(fmt)}
                      className={`py-3 px-2 rounded-2xl font-black text-xs uppercase tracking-wider flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95 border cursor-pointer ${
                        isSelected
                          ? 'bg-orange-500 text-white border-orange-400 shadow-lg shadow-orange-500/30'
                          : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/60'
                      }`}
                    >
                      <i className={`fas ${icon} text-base`}></i>
                      <span>{fmt}</span>
                    </button>
                  );
                })}
              </div>

              {/* Multi-Page Mode Options (when multiple pages exist) */}
              {targetPages.length > 1 && (
                <div className="pt-2 border-t border-slate-800/80 space-y-2">
                  <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                    Multi-Page Mode:
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setPageExportMode('merged')}
                      className={`py-2 px-2 rounded-xl text-[11px] font-bold flex flex-col items-center text-center gap-1 border transition-all active:scale-95 cursor-pointer ${
                        pageExportMode === 'merged'
                          ? 'bg-slate-800 text-teal-300 border-teal-500/60 shadow-xs'
                          : 'bg-slate-950/50 text-slate-400 border-slate-800 hover:text-slate-300'
                      }`}
                    >
                      <i className="fas fa-layer-group text-xs"></i>
                      <span>Single Merged</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPageExportMode('separate')}
                      className={`py-2 px-2 rounded-xl text-[11px] font-bold flex flex-col items-center text-center gap-1 border transition-all active:scale-95 cursor-pointer ${
                        pageExportMode === 'separate'
                          ? 'bg-slate-800 text-teal-300 border-teal-500/60 shadow-xs'
                          : 'bg-slate-950/50 text-slate-400 border-slate-800 hover:text-slate-300'
                      }`}
                    >
                      <i className="fas fa-copy text-xs"></i>
                      <span>Separate Files</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPageExportMode('zip')}
                      className={`py-2 px-2 rounded-xl text-[11px] font-bold flex flex-col items-center text-center gap-1 border transition-all active:scale-95 cursor-pointer ${
                        pageExportMode === 'zip'
                          ? 'bg-slate-800 text-teal-300 border-teal-500/60 shadow-xs'
                          : 'bg-slate-950/50 text-slate-400 border-slate-800 hover:text-slate-300'
                      }`}
                    >
                      <i className="fas fa-file-zipper text-xs"></i>
                      <span>In ZIP (.zip)</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* 2. COMPRESSION & QUALITY CARD (WITH LIVE ESTIMATED FILE SIZE) */}
            <div
              ref={compressionSectionRef}
              className={`w-full bg-slate-900/80 border rounded-3xl p-4 sm:p-5 text-left space-y-3.5 backdrop-blur-md transition-all duration-500 ${
                isCompressionHighlighted
                  ? 'border-amber-400 ring-4 ring-amber-400/20 shadow-2xl shadow-amber-500/20'
                  : 'border-slate-800/90'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center text-xs font-black">
                    2
                  </span>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-200">
                    Compression &amp; Quality
                  </h3>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1">
                  <i className="fas fa-bolt"></i> Live Estimate
                </span>
              </div>

              {/* 3 Compression Presets */}
              <div className="space-y-2">
                {/* 1. As It Is (Original - 100%) */}
                <div
                  onClick={() => setCompressionPreset('original')}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 active:scale-[0.99] ${
                    compressionPreset === 'original'
                      ? 'bg-slate-800/90 border-teal-500 shadow-md shadow-teal-500/10'
                      : 'bg-slate-950/40 border-slate-800/70 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        compressionPreset === 'original'
                          ? 'border-teal-400 bg-teal-500'
                          : 'border-slate-600'
                      }`}
                    >
                      {compressionPreset === 'original' && (
                        <div className="w-2 h-2 rounded-full bg-slate-950"></div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-white">
                          As It Is (Original - 100%)
                        </span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded font-black uppercase bg-slate-700 text-slate-300">
                          MAX RES
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">
                        No compression, maximum clarity &amp; full resolution
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-black text-slate-200 font-mono">
                      ~{liveEstimates.original.formatted}
                    </div>
                    <div className="text-[10px] text-slate-500">Raw Capture</div>
                  </div>
                </div>

                {/* 2. Medium Compress (Balanced - 70%) - Default Selected */}
                <div
                  onClick={() => setCompressionPreset('medium')}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 active:scale-[0.99] ${
                    compressionPreset === 'medium'
                      ? 'bg-emerald-950/30 border-emerald-500 shadow-md shadow-emerald-500/10'
                      : 'bg-slate-950/40 border-slate-800/70 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        compressionPreset === 'medium'
                          ? 'border-emerald-400 bg-emerald-500'
                          : 'border-slate-600'
                      }`}
                    >
                      {compressionPreset === 'medium' && (
                        <div className="w-2 h-2 rounded-full bg-slate-950"></div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-emerald-300">
                          Medium Compress (Balanced - 70%)
                        </span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          RECOMMENDED
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">
                        Ideal for WhatsApp &amp; Email sharing
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-black text-emerald-300 font-mono">
                      ~{liveEstimates.medium.formatted}
                    </div>
                    <div className="text-[10px] text-emerald-400 font-bold">
                      -{liveEstimates.medium.savingsPercent}% Saved
                    </div>
                  </div>
                </div>

                {/* 3. Extreme Compress (Small Size - 40%) */}
                <div
                  onClick={() => setCompressionPreset('extreme')}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 active:scale-[0.99] ${
                    compressionPreset === 'extreme'
                      ? 'bg-amber-950/30 border-amber-500 shadow-md shadow-amber-500/10'
                      : 'bg-slate-950/40 border-slate-800/70 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        compressionPreset === 'extreme'
                          ? 'border-amber-400 bg-amber-500'
                          : 'border-slate-600'
                      }`}
                    >
                      {compressionPreset === 'extreme' && (
                        <div className="w-2 h-2 rounded-full bg-slate-950"></div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-amber-300">
                          Extreme Compress (Small Size - 40%)
                        </span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          GOVT FORMS
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">
                        Strict limits under 100KB–200KB (Aadhaar, UPSC)
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-black text-amber-300 font-mono">
                      ~{liveEstimates.extreme.formatted}
                    </div>
                    <div className="text-[10px] text-amber-400 font-bold">
                      -{liveEstimates.extreme.savingsPercent}% Saved
                    </div>
                  </div>
                </div>
              </div>

              {/* Live size summary indicator */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-300">
                  <i className="fas fa-chart-pie text-teal-400 text-xs"></i>
                  <span>Est. File Size:</span>
                  <span className="font-mono font-black text-teal-300">
                    ~{currentEstimate.formatted}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  {compressionPreset === 'original' ? (
                    'Original 100%'
                  ) : (
                    <span className="text-emerald-400 font-bold">
                      Save ~{'savingsPercent' in currentEstimate ? currentEstimate.savingsPercent : 0}% vs raw
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* 3. MAIN ACTION BUTTONS */}
            <div className="w-full space-y-3 pt-1">
              {/* DOWNLOAD FILE BUTTON */}
              <button
                type="button"
                id="btn-export-download-file"
                onClick={handleExportDownloadAction}
                disabled={isExportingAction}
                aria-label={`Download file in ${exportFormatSelection} format`}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white py-4 px-6 rounded-2xl font-black text-base shadow-2xl shadow-orange-500/25 active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-wider disabled:opacity-50 cursor-pointer"
              >
                <i className="fas fa-file-arrow-down text-xl"></i>
                <span>DOWNLOAD FILE ({exportFormatSelection})</span>
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                {/* COMPRESS FILE BUTTON (Focuses compression presets) */}
                <button
                  type="button"
                  onClick={handleCompressFocusClick}
                  className="w-full bg-slate-800/90 hover:bg-slate-700 text-amber-300 border border-amber-500/40 py-3.5 px-3 rounded-2xl font-black text-xs uppercase tracking-wider active:scale-95 transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer"
                >
                  <i className="fas fa-file-zipper text-sm text-amber-400"></i>
                  <span>COMPRESS FILE</span>
                </button>

                {/* SHARE FILE BUTTON */}
                <button
                  type="button"
                  onClick={handleExportShareAction}
                  disabled={isExportingAction}
                  className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white py-3.5 px-3 rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-indigo-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  <i className="fas fa-share-nodes text-sm"></i>
                  <span>SHARE FILE</span>
                </button>
              </div>

              {hasDownloaded && (
                <DownloadSuccessAdArea
                  downloadKey={state.resultFileName || folderName}
                  className="mt-2 pt-1"
                />
              )}

              {/* Back to Document Folder */}
              <button
                type="button"
                onClick={() => {
                  setState({ status: 'idle', progress: 0 });
                  setHasDownloaded(false);
                  setUiStep('gallery');
                }}
                className="w-full text-white/50 font-black text-[11px] uppercase tracking-[0.25em] py-3 hover:text-teal-400 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <i className="fas fa-arrow-left text-xs"></i>
                <span>BACK TO DOCUMENT FOLDER</span>
              </button>
            </div>
          </div>

          {quickCompressModalOpen && state.resultUrl && (
            <QuickCompressModal
              isOpen={quickCompressModalOpen}
              onClose={() => setQuickCompressModalOpen(false)}
              fileSource={currentResultBlob || state.resultUrl}
              fileName={state.resultFileName || `${folderName}.${exportFormatSelection.toLowerCase()}`}
              fileType={state.resultFileName?.toLowerCase().endsWith('.pdf') ? 'pdf' : 'image'}
            />
          )}

          <div className="w-full shrink-0">
            <BannerAdBar isOverlay={true} />
          </div>
        </div>
      )}

      {/* Global Bottom AdMob Reserved Slot (keeps Gallery & Preview buttons above the 60px native banner) */}
      {uiStep !== 'camera' && state.status !== 'success' && (
        <div className="w-full shrink-0 bg-[#020617]">
          <BannerAdBar isOverlay={true} />
        </div>
      )}

      {/* Floating Snackbar Toast with OPEN Action */}
      {snackbar.visible && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[9999] max-w-sm w-[90%] bg-slate-900/95 backdrop-blur-xl border border-teal-500/40 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-400 text-xs shrink-0">
              <i className="fas fa-check"></i>
            </div>
            <p className="text-xs font-bold text-white truncate">{snackbar.message}</p>
          </div>
          {snackbar.actionLabel && (
            <button
              type="button"
              onClick={() => {
                snackbar.onAction?.();
                setSnackbar((s) => ({ ...s, visible: false }));
              }}
              className="px-3 py-1.5 bg-teal-500 hover:bg-teal-400 active:scale-95 text-slate-950 font-black text-[10px] uppercase tracking-wider rounded-xl transition-all shrink-0 cursor-pointer shadow-md shadow-teal-500/30"
            >
              {snackbar.actionLabel}
            </button>
          )}
        </div>
      )}

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
};

export default Scan;