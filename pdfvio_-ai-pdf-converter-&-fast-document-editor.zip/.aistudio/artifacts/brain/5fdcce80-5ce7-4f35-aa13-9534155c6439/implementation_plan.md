# Download Flow to Export Studio & Saved Location Confirmation Plan

Update the Scanned Documents screen so tapping the Download button opens the comprehensive Export Studio screen first without auto-downloading. Inside the Export Studio, users can inspect their document, toggle format and compression presets with live size estimation, and execute the direct download with the Saved Location Confirmation Card.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences are confirmed:
> - **Download Button on Scanned Documents Screen**: Tapping the Download button (floating Download FAB `#documents-download-fab` and gallery header action `#btn-download-scan`) opens the Export Studio screen first instead of triggering an immediate automatic download.
> - **Export Studio Layout**: Retains the complete Export Studio with format options (PDF, JPG, PNG, ZIP), page modes (Single Merged, Separate Files, In ZIP), and 3 Compression Presets (Original 100%, Medium Balanced 70%, Extreme Small 40%) with real-time size estimators.
> - **Download Inside Export Screen**: Direct download executes when the user taps "DOWNLOAD FILE" inside the Export Studio, triggering `window.AndroidBridge.downloadFile` or browser download with AdMob interstitial support, immediately showing the "DONE!" banner and the green "Saved Location / Folder Path" Confirmation Card with working "Open File" and "Share Now" buttons.

- **Confirmed Decision 1**: Both the floating download FAB and the gallery top/action bar Download button will invoke `handleOpenExportStudio()`.
- **Confirmed Decision 2**: Multi-select Export and top menu Export options will also route directly to `handleOpenExportStudio()`, deprecating redundant legacy sheets.
- **Confirmed Decision 3**: The hero banner on the Export Studio will cleanly transition from `EXPORT DOCUMENT` (pre-download review state) to `DONE!` (post-download confirmation state) when download completes.

---

## 1. Overview & Core Concept

Currently, tapping the Download button in the gallery automatically compiles and downloads the PDF directly, skipping user review.

This change connects the Download buttons on the Scanned Documents screen to the **Advanced Export, Compression & Share Studio**, allowing users to:
1. Preview document details, page count, and estimated file size.
2. Select desired format (`.pdf`, `.jpg`, `.png`, `.zip`) and multi-page modes (Single Merged, Separate Files, In ZIP).
3. Choose from 3 compression presets with dynamic live size estimation:
   - **As It Is (Original - 100%)**: Raw resolution, uncompressed.
   - **Medium Compress (Balanced - 70%)**: Default pre-selection, 1600px max dimension, 0.72 quality (~65–75% reduction).
   - **Extreme Compress (Small Size - 40%)**: 1000px max dimension, 0.45 quality, targeted strictly under 150KB–200KB for government and job portal limits (Aadhaar, UPSC, SSC).
4. Tap **DOWNLOAD FILE** inside the Export screen to save to storage, showing the green **Saved Location / Folder Path** confirmation card with one-tap "Open File" and "Share Now" actions.

---

## 2. User Experience & Visual Design

### User Journey Flow
```
┌─────────────────────────────────┐
│     Scanned Documents Screen     │
│   (Gallery of captured pages)   │
└────────────────┬────────────────┘
                 │
                 │ User taps "Download" FAB or Button
                 ▼
┌────────────────────────────────────────────────────────┐
│               Export Studio Screen                     │
│  • Hero: "EXPORT DOCUMENT" (Est. size, page count)    │
│  • Section 1: File Format (PDF/JPG/PNG/ZIP) & Mode     │
│  • Section 2: 3 Compression Presets (Original/Med/Ext) │
│  • Live Size Badge: ~180 KB (-72% Saved vs raw)        │
└────────────────┬───────────────────────────────────────┘
                 │
                 │ User taps "DOWNLOAD (PDF)"
                 ▼
┌────────────────────────────────────────────────────────┐
│               Post-Download "DONE!" Screen             │
│  • Hero: "DONE!" with double-check icon                │
│  • Green "Saved Location / Folder Path" Card:          │
│      ├── File Name: Scan_Project_01.pdf                │
│      ├── Folder Location: Internal Storage > Downloads │
│      ├── [Open File] button (native intent / viewer)   │
│      └── [Share Now] button (native share sheet)       │
│  • COMPRESS FILE & SHARE FILE secondary actions        │
└────────────────────────────────────────────────────────┘
```

- **Visual Contrast**: Sleek obsidian dark background (`#020617`) with emerald/teal status accents, amber highlights for government extreme compression, and high-visibility touch targets.
- **Smooth Navigation**: One-tap "Folder" back button in sticky header returns to the gallery at any time without losing captured pages.

---

## 3. Key Product Decisions & Trade-Offs

- **Pre-download Review vs Immediate Download**: Opening the Export Studio first gives users control over compression presets and format before saving, preventing bloated files or incorrect formats from filling phone storage.
- **State Separation**: Opening the studio sets `state.status = 'success'` with `hasDownloaded = false`, clearly distinguishing the pre-download review phase from the post-download "DONE!" phase.
- **Universal Bridge & Web Fallback**: Seamless operation across Android WebView (`window.AndroidBridge`) and standard web browsers with unified `Saved Location` feedback.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────────┐
│                                 Scan.tsx                                   │
├────────────────────────────────────────────────────────────────────────────┤
│  Gallery View:                                                             │
│    • #btn-download-scan        ──┐                                         │
│    • #documents-download-fab   ──┼──> handleOpenExportStudio()             │
│    • Top Menu & Multi-Select   ──┘      │                                  │
│                                         ▼                                  │
│                           setHasDownloaded(false)                          │
│                           setSavedFeedback(null)                           │
│                           setState({ status: 'success' })                  │
├────────────────────────────────────────────────────────────────────────────┤
│  Export Studio View (state.status === 'success'):                         │
│    • Live size calculation: calculateLiveEstimates()                       │
│    • Compression selector: original | medium | extreme                     │
│    • Format selector: PDF | JPG | PNG | ZIP                                │
│    • Page mode selector: merged | separate | zip                           │
│                                                                            │
│    [DOWNLOAD FILE] ──> handleExportDownloadAction()                        │
│                          ├── buildExportBundle(selected options)           │
│                          ├── AndroidBridge.downloadFile || browser save    │
│                          ├── setHasDownloaded(true)                        │
│                          └── setSavedFeedback(folder path, file details)   │
│                                                                            │
│    [COMPRESS FILE] ──> Smooth scroll to Section 2 with highlight pulse     │
│    [SHARE FILE]    ──> AndroidBridge.shareFile || navigator.share          │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Implementation Steps

1. **Create `handleOpenExportStudio` in `pages/Scan.tsx`**:
   - Validates that `capturedPages.length > 0`.
   - Resets `hasDownloaded` to `false` and clears previous `savedFeedback`.
   - Pre-populates default `exportFormatSelection = 'PDF'` and `compressionPreset = 'medium'`.
   - Sets `state.status = 'success'`.

2. **Wire Scanned Document Download Triggers**:
   - Update `#btn-download-scan` in the gallery header to call `handleOpenExportStudio`.
   - Update `#documents-download-fab` (floating download button) to call `handleOpenExportStudio`.
   - Update multi-select "Export" footer button and top menu "Export All Pages" to call `handleOpenExportStudio`.

3. **Verify Export Studio Direct Download Flow**:
   - Verify that clicking "DOWNLOAD (PDF)" inside the Export Studio calls `handleExportDownloadAction`.
   - Confirms AdMob interstitial display, invokes `window.AndroidBridge.downloadFile` (or browser download), sets `hasDownloaded = true`, and displays the "Saved Location / Folder Path" confirmation card with "Open File" and "Share Now" buttons.

4. **Compile & Lint Verification**:
   - Run `compile_applet` and `lint_applet` to ensure zero compilation or TypeScript errors.
