import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  
  const args = process.argv.slice(2);
  let cliPort: number | null = null;
  let cliHost: string | null = null;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--port' && args[i + 1]) {
      cliPort = Number(args[i + 1]);
    }
    if (args[i] === '--host' && args[i + 1]) {
      cliHost = args[i + 1];
    }
  }

  const PORT = Number(process.env.PORT) || cliPort || 3000;
  const HOST = process.env.HOST || cliHost || '0.0.0.0';

  // Support large base64 image scan uploads (up to 50MB)
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Initialize Google GenAI SDK on server-side using free tier Gemini API
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Health check endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'PDFVio Google AI Document Scanner',
      model: 'gemini-3.1-flash-lite / gemini-3.8-flash (Free)',
      timestamp: new Date().toISOString(),
    });
  });

  // Google AI Free Image Scanner Endpoint
  app.post('/api/scan-image', async (req: Request, res: Response): Promise<any> => {
    try {
      const { image, mimeType = 'image/jpeg', mode = 'ocr', prompt: userPrompt } = req.body;

      if (!image) {
        return res.status(400).json({ success: false, error: 'No image data provided' });
      }

      // Strip data URL header if present
      const cleanBase64 = typeof image === 'string' && image.includes('base64,')
        ? image.split('base64,')[1]
        : String(image);

      let detectedMime = mimeType;
      if (typeof image === 'string' && image.startsWith('data:')) {
        const match = image.match(/^data:([^;]+);base64,/);
        if (match) detectedMime = match[1];
      }

      const systemPrompt = `You are an expert document scanner and optical character recognition (OCR) engine powered by Google AI.
Analyze this scanned image and perform high-accuracy text extraction and document identification.
Support English, Hindi (Devanagari), Marathi, and other regional Indian languages, numbers, tables, and layouts.

${mode === 'aadhaar_extract' ? 'The user is scanning an Indian Identity Document (e.g. Aadhaar Card, PAN Card, Voter ID). Extract all key identity fields carefully.' : ''}

Return a valid JSON object matching this schema:
{
  "extractedText": "exact text transcription preserving lines and layout",
  "documentType": "type of document (e.g. Aadhaar Card, PAN Card, Voter ID Card, Driving License, Passport, Marksheet, Certificate, Bill/Invoice, Receipt, Business Card, Handwritten Note, General Document)",
  "language": "detected languages (e.g. English, Hindi, Marathi, etc.)",
  "summary": "a clear 1-2 sentence summary of what this document is",
  "scanQuality": "excellent | good | fair | poor",
  "qualityTips": "helpful guidance to improve the scan if needed, or empty string if clear",
  "fields": {
    "name": "full name if present",
    "idNumber": "document/card number (e.g., Aadhaar, PAN, Voter ID, License number) if present",
    "dobOrYob": "Date of Birth or Year of Birth if present",
    "gender": "Male / Female / Other if present",
    "fatherOrHusbandName": "father or husband name if present",
    "address": "full address if present",
    "issueDate": "issue date if present",
    "expiryDate": "expiry date if present"
  }
}
Output only pure JSON. Do not wrap in markdown or backticks.`;

      // Free tier models: gemini-3.1-flash-lite (fastest, free), fallback to gemini-3.8-flash
      const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];
      let lastError: any = null;
      let responseText = '';

      for (const model of modelsToTry) {
        try {
          const aiResponse = await ai.models.generateContent({
            model,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: detectedMime,
                    data: cleanBase64,
                  },
                },
                {
                  text: userPrompt ? `${systemPrompt}\n\nAdditional user instructions: ${userPrompt}` : systemPrompt,
                },
              ],
            },
          });

          responseText = aiResponse.text || '';
          if (responseText) break;
        } catch (err: any) {
          lastError = err;
          console.warn(`[Scan API] Model ${model} returned error, checking alternative:`, err.message);
        }
      }

      if (!responseText) {
        throw lastError || new Error('No response generated by Google AI model');
      }

      let parsedData: any = {};
      try {
        const cleaned = responseText.replace(/```json/gi, '').replace(/```/g, '').trim();
        parsedData = JSON.parse(cleaned);
      } catch (e) {
        parsedData = {
          extractedText: responseText.trim(),
          documentType: 'Scanned Document',
          language: 'Auto-detected',
          summary: 'Scanned document text extracted with Google AI.',
          scanQuality: 'good',
          qualityTips: '',
          fields: {},
        };
      }

      return res.json({
        success: true,
        ...parsedData,
      });
    } catch (error: any) {
      console.error('[Scan API] Error scanning image:', error);
      return res.status(500).json({
        success: false,
        error: error.message || 'Failed to scan image with Google AI',
      });
    }
  });

  // Batch scan endpoint for multiple pages
  app.post('/api/scan-document-batch', async (req: Request, res: Response): Promise<any> => {
    try {
      const { pages } = req.body;
      if (!Array.isArray(pages) || pages.length === 0) {
        return res.status(400).json({ success: false, error: 'Pages array required' });
      }

      const results = [];
      for (let i = 0; i < pages.length; i++) {
        const page = pages[i];
        const cleanBase64 = typeof page.image === 'string' && page.image.includes('base64,')
          ? page.image.split('base64,')[1]
          : String(page.image);

        let detectedMime = page.mimeType || 'image/jpeg';
        if (typeof page.image === 'string' && page.image.startsWith('data:')) {
          const match = page.image.match(/^data:([^;]+);base64,/);
          if (match) detectedMime = match[1];
        }

        try {
          const aiResponse = await ai.models.generateContent({
            model: 'gemini-3.1-flash-lite',
            contents: {
              parts: [
                { inlineData: { mimeType: detectedMime, data: cleanBase64 } },
                {
                  text: 'Extract all visible text from this scanned page accurately. Preserve layout, headings, and paragraphs. Support English, Hindi, Marathi, and numbers. Return only the extracted text.',
                },
              ],
            },
          });
          results.push({
            id: page.id,
            name: page.name || `Page ${i + 1}`,
            text: (aiResponse.text || '').trim(),
            success: true,
          });
        } catch (pageErr: any) {
          results.push({
            id: page.id,
            name: page.name || `Page ${i + 1}`,
            text: `[Google AI Scan failed for page ${i + 1}: ${pageErr.message}]`,
            success: false,
          });
        }
      }

      return res.json({
        success: true,
        results,
      });
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  const isDev = process.env.NODE_ENV !== 'production';
  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true, allowedHosts: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
